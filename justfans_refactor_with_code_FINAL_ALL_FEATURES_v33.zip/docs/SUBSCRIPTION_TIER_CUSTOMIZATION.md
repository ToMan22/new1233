# 🧩 Subscription Tier Customization

Allow creators to define multiple subscription levels with varying pricing, benefits, and visibility.

---

## 🧱 1. Migrations

**subscription_tiers**

```php
Schema::create('subscription_tiers', function (Blueprint $table) {
    $table->id();
    $table->foreignId('creator_id')->constrained('users');
    $table->string('name');
    $table->decimal('price', 6, 2);
    $table->text('description')->nullable();
    $table->boolean('is_visible')->default(true);
    $table->timestamps();
});
```

**tier_subscriptions**

```php
Schema::create('tier_subscriptions', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->foreignId('subscription_tier_id')->constrained();
    $table->timestamp('starts_at')->nullable();
    $table->timestamp('ends_at')->nullable();
    $table->timestamps();
});
```

---

## 🎛️ 2. Creator UI for Tier Setup

```blade
<form method="POST" action="{{ route('tiers.store') }}">
  @csrf
  <input type="text" name="name" placeholder="Tier Name" required>
  <input type="number" step="0.01" name="price" placeholder="Price" required>
  <textarea name="description" placeholder="Benefits of this tier"></textarea>
  <button type="submit">Create Tier</button>
</form>
```

---

## 📥 3. Fan View & Subscription

```blade
@foreach($creator->tiers as $tier)
  <div class="border p-4 mb-3">
    <h3>{{ $tier->name }} — ${{ $tier->price }}</h3>
    <p>{{ $tier->description }}</p>
    <form method="POST" action="{{ route('tiers.subscribe', $tier) }}">
      @csrf
      <button>Subscribe</button>
    </form>
  </div>
@endforeach
```

---

## 📡 4. Controller Snippets

```php
public function store(Request $request)
{
    SubscriptionTier::create([
        'creator_id' => auth()->id(),
        'name' => $request->name,
        'price' => $request->price,
        'description' => $request->description,
    ]);

    return back()->with('success', 'Tier created.');
}

public function subscribe(Request $request, SubscriptionTier $tier)
{
    TierSubscription::create([
        'user_id' => auth()->id(),
        'subscription_tier_id' => $tier->id,
        'starts_at' => now(),
        'ends_at' => now()->addMonth(),
    ]);

    return back()->with('success', 'Subscribed!');
}
```

---

## 🔐 5. Route Protection (Optional)

Allow creators to post tier-only content using middleware like:

```php
if (auth()->user()?->tierAccess($post->required_tier_id)) {
  // show content
}
```

---

## ✅ Optional Enhancements

- Icons and perks per tier
- Limit post visibility by tier
- Discount codes, trial periods
- Tier analytics

Inspired by:
- [Ko-fi Memberships](https://ko-fi.com/)
- [Laravel Cashier tier integrations](https://github.com/laravel/cashier)

