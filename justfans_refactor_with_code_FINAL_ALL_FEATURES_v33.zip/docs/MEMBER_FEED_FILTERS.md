# 🎛️ Member Feed Filters (Non-Dynamic URL Approach)

Allow members to filter feed content by attributes like age, content type, tags, ethnicity — without using dynamic URLs.

---

## 🧱 1. Feed Filter Schema (Optional)

```php
Schema::table('posts', function (Blueprint $table) {
    $table->string('content_type')->nullable(); // 'video', 'image', 'text'
    $table->string('ethnicity')->nullable();
    $table->integer('model_age')->nullable(); // if applicable
});
```

---

## 📋 2. Admin-Editable Filter Options

Use an editable config or admin panel UI to control filter categories.

```php
// config/feed-filters.php
return [
    'ethnicity' => ['Asian', 'Black', 'White', 'Mixed', 'Latina'],
    'content_type' => ['video', 'image', 'audio', 'text'],
    'age' => [18, 21, 25, 30, 35, 40],
];
```

---

## 🎛️ 3. Blade Filter Form UI

```blade
<form method="GET" id="filtersForm">
  <select name="ethnicity" onchange="this.form.submit()">
    <option value="">Ethnicity</option>
    @foreach(config('feed-filters.ethnicity') as $eth)
      <option value="{{ $eth }}" {{ request('ethnicity') === $eth ? 'selected' : '' }}>{{ $eth }}</option>
    @endforeach
  </select>

  <select name="content_type" onchange="this.form.submit()">
    <option value="">Type</option>
    @foreach(config('feed-filters.content_type') as $type)
      <option value="{{ $type }}" {{ request('content_type') === $type ? 'selected' : '' }}>{{ ucfirst($type) }}</option>
    @endforeach
  </select>

  <select name="age" onchange="this.form.submit()">
    <option value="">Model Age</option>
    @foreach(config('feed-filters.age') as $age)
      <option value="{{ $age }}" {{ request('age') == $age ? 'selected' : '' }}>{{ $age }}+</option>
    @endforeach
  </select>
</form>
```

---

## 🔍 4. Filter Logic in Controller

```php
$query = Post::query();

if ($ethnicity = request('ethnicity')) {
    $query->where('ethnicity', $ethnicity);
}
if ($type = request('content_type')) {
    $query->where('content_type', $type);
}
if ($age = request('age')) {
    $query->where('model_age', '>=', $age);
}

$posts = $query->latest()->paginate(20);
```

---

## 🧠 Benefits of Non-Dynamic URLs

- Filter values passed as query params (`?ethnicity=Asian&type=video`)
- Easy to combine filters
- SEO-safe and no route pollution

---

## ✅ Optional Enhancements

- Alpine.js to reset filters dynamically
- Store user filter preferences in DB
- Filter by tag intersection
- Role-gated filters for premium users

Inspired by:
- [Laravel Nova filters](https://nova.laravel.com/)
- [Livewire + Alpine filters](https://github.com/laravel-filament/filament)

