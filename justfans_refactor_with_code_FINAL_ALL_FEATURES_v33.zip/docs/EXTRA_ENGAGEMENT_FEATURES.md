# 🌟 Extra Engagement Features

This module introduces three engagement systems:
- 🏆 Contest Leaderboards
- 🏅 User / Creator Badges
- 📦 Discount & Trial Codes

---

## 🏆 1. Contest Leaderboards

**Migration**

```php
Schema::create('contest_entries', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->string('title');
    $table->text('media_url');
    $table->unsignedInteger('votes')->default(0);
    $table->timestamps();
});
```

**Voting Logic**

```php
Route::post('/contest/vote/{entry}', function ($entry) {
    $entry->increment('votes');
    return back()->with('success', 'Vote cast!');
});
```

**Leaderboard Display**

```blade
@foreach($entries->sortByDesc('votes') as $entry)
  <div>
    <strong>{{ $entry->title }}</strong> – {{ $entry->votes }} votes
  </div>
@endforeach
```

---

## 🏅 2. User & Creator Badges

**Migration**

```php
Schema::create('badges', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('icon');
    $table->timestamps();
});

Schema::create('badge_user', function (Blueprint $table) {
    $table->id();
    $table->foreignId('badge_id')->constrained();
    $table->foreignId('user_id')->constrained();
});
```

**Badge Awarding**

```php
BadgeUser::create([
    'badge_id' => $badge->id,
    'user_id' => $user->id,
]);
```

**Display in Profile**

```blade
@foreach($user->badges as $badge)
  <img src="{{ asset('badges/' . $badge->icon) }}" alt="{{ $badge->name }}" />
@endforeach
```

---

## 📦 3. Discount & Trial Codes

**Migration**

```php
Schema::create('discount_codes', function (Blueprint $table) {
    $table->id();
    $table->string('code')->unique();
    $table->decimal('discount_percent', 5, 2)->nullable();
    $table->integer('days_free')->nullable();
    $table->timestamp('expires_at')->nullable();
    $table->timestamps();
});
```

**Redeem Logic at Checkout**

```php
if ($code = DiscountCode::where('code', $input)->where('expires_at', '>', now())->first()) {
    if ($code->days_free) {
        $subscription->starts_at = now();
        $subscription->ends_at = now()->addDays($code->days_free);
    }
}
```

---

## ✅ Optional Enhancements

- Leaderboard filters: category, time period
- Badge automation (e.g. top referrer, contest winner)
- Discount redemption limits and tracking

