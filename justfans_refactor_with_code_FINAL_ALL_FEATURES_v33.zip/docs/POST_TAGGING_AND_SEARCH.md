# 🏷️ Creator Post Tagging & 🔍 Advanced Search Indexing

Add tagging to posts and power creator/content search by tag, title, or body.

---

## 🧾 1. Migrations

**Tags Table**

```php
Schema::create('tags', function (Blueprint $table) {
    $table->id();
    $table->string('name')->unique();
    $table->timestamps();
});
```

**Pivot Table**

```php
Schema::create('post_tag', function (Blueprint $table) {
    $table->id();
    $table->foreignId('post_id')->constrained();
    $table->foreignId('tag_id')->constrained();
});
```

---

## 🧩 2. Models & Relationships

```php
// Post.php
public function tags() {
    return $this->belongsToMany(Tag::class);
}

// Tag.php
public function posts() {
    return $this->belongsToMany(Post::class);
}
```

---

## ✍️ 3. Post Form with Tagging (Blade)

```blade
<input type="text" name="tags" placeholder="Comma separated: music, funny, parody" />
```

---

## 🎯 4. PostController Store Logic

```php
$tags = collect(explode(',', $request->tags))
    ->map(fn($t) => trim(strtolower($t)))
    ->unique();

$post->tags()->sync(
    Tag::firstOrCreateBatch($tags->map(fn($tag) => ['name' => $tag])->toArray())->pluck('id')
);
```

---

## 🔍 5. Basic Search by Tag, Title, or Body

```php
$query = Post::query();

if ($term = $request->search) {
    $query->where('title', 'like', "%{$term}%")
          ->orWhere('body', 'like', "%{$term}%")
          ->orWhereHas('tags', fn($q) => $q->where('name', 'like', "%{$term}%"));
}

$results = $query->paginate(20);
```

---

## 🧠 6. Optional Improvements

- Tag auto-complete in UI (e.g., Trix, Alpine.js, Select2)
- Show trending tags
- Laravel Scout or Meilisearch for fuzzy/full-text
- Caching popular tag results

Inspired by:
- [Laravel Nova Taggable Field](https://github.com/spatie/nova-tags-field)
- [Laravel Scout](https://laravel.com/docs/scout)
- [MeiliSearch integration](https://github.com/meilisearch/meilisearch-laravel)

