# 📊 Real-Time Admin & Creator Dashboards

Dashboards deliver real-time metrics to admins and creators using Laravel Livewire.

---

## ⚙️ 1. Install Livewire (if not yet)

```bash
composer require livewire/livewire
npm install
```

Add to Blade layout:

```blade
@livewireStyles
...
@livewireScripts
```

---

## 🧑‍🎤 2. Creator Dashboard (Livewire Component)

```bash
php artisan make:livewire CreatorDashboard
```

**`CreatorDashboard.php`**

```php
class CreatorDashboard extends Component
{
    public $subscribers, $earnings, $posts;

    public function mount()
    {
        $user = auth()->user();
        $this->subscribers = $user->subscribers()->count();
        $this->posts = $user->posts()->count();
        $this->earnings = $user->payments()->sum('amount');
    }

    public function render()
    {
        return view('livewire.creator-dashboard');
    }
}
```

**`creator-dashboard.blade.php`**

```blade
<div>
  <h1 class="text-xl font-bold">🎨 Creator Dashboard</h1>
  <div class="grid grid-cols-3 gap-4">
    <div class="card">👥 Subscribers: {{ $subscribers }}</div>
    <div class="card">💰 Earnings: ${{ number_format($earnings, 2) }}</div>
    <div class="card">📝 Posts: {{ $posts }}</div>
  </div>
</div>
```

---

## 👑 3. Admin Dashboard (Livewire Component)

```bash
php artisan make:livewire AdminDashboard
```

**`AdminDashboard.php`**

```php
class AdminDashboard extends Component
{
    public $users, $creators, $posts;

    public function mount()
    {
        $this->users = User::count();
        $this->creators = User::where('role', 'creator')->count();
        $this->posts = Post::count();
    }

    public function render()
    {
        return view('livewire.admin-dashboard');
    }
}
```

**`admin-dashboard.blade.php`**

```blade
<div>
  <h1 class="text-xl font-bold">📊 Admin Overview</h1>
  <div class="grid grid-cols-3 gap-4">
    <div class="card">👥 Total Users: {{ $users }}</div>
    <div class="card">🎭 Creators: {{ $creators }}</div>
    <div class="card">🖼️ Posts: {{ $posts }}</div>
  </div>
</div>
```

---

## 🧠 Optional Enhancements

- Live data refresh (`$this->refresh()` with polling)
- Monthly revenue graph (e.g., with Chart.js)
- Per-day breakdown for content performance

Inspired by:
- [Livewire Docs](https://livewire.laravel.com/)
- [TallStackUI Dashboard](https://github.com/usetall/tallstackui)

