# 🕵️ Admin Audit Dashboard & Search Filters

Enable comprehensive content auditing and flexible filtering for admins across users, posts, and activity.

---

## 🧱 1. Optional Audit Log Table (Activity Feed)

```php
Schema::create('audit_logs', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->nullable()->constrained();
    $table->string('action'); // e.g. 'post_approved', 'login', 'profile_update'
    $table->json('context')->nullable(); // optional metadata
    $table->timestamps();
});
```

---

## 🔍 2. Filtering Setup (Example for Posts)

**Controller:**

```php
public function index(Request $request)
{
    $query = Post::query();

    if ($request->filled('status')) {
        $query->where('status', $request->status);
    }
    if ($request->filled('creator')) {
        $query->where('user_id', $request->creator);
    }
    if ($request->filled('date_from')) {
        $query->whereDate('created_at', '>=', $request->date_from);
    }

    $posts = $query->with('user')->latest()->paginate(20);
    return view('admin.posts.index', compact('posts'));
}
```

**Blade UI:**

```blade
<form method="GET">
  <select name="status">
    <option value="">All Statuses</option>
    <option value="pending">Pending</option>
    <option value="approved">Approved</option>
  </select>

  <input type="text" name="creator" placeholder="Creator ID">
  <input type="date" name="date_from">
  <button class="btn">🔍 Filter</button>
</form>
```

---

## 🧠 3. Audit Log Writing (Anywhere)

```php
AuditLog::create([
    'user_id' => auth()->id(),
    'action' => 'post_approved',
    'context' => json_encode(['post_id' => $post->id]),
]);
```

---

## 📋 4. Admin Dashboard Table

```blade
<table>
  <tr><th>ID</th><th>User</th><th>Action</th><th>Date</th></tr>
  @foreach($logs as $log)
    <tr>
      <td>{{ $log->id }}</td>
      <td>{{ $log->user?->name ?? 'System' }}</td>
      <td>{{ $log->action }}</td>
      <td>{{ $log->created_at }}</td>
    </tr>
  @endforeach
</table>
```

---

## ✅ Optional Enhancements

- Link filters to global search (via Laravel Scout or Meilisearch)
- Admin impersonation tracking
- Export filtered logs to CSV
- Role-based audit scopes

Inspired by:
- [Laravel Telescope](https://laravel.com/docs/telescope)
- [Nova/Filament filters](https://filamentphp.com/docs/tables/filters/)

