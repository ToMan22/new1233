# 🧠 Smart Content Recommendations (Tags & Engagement-Based)

Serve relevant content to users based on tags they engage with, recent views, and liked posts.

---

## 📊 1. Engagement Tracking Table (Optional)

```php
Schema::create('post_views', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->nullable()->constrained();
    $table->foreignId('post_id')->constrained();
    $table->timestamps();
});
```

Also optionally: `likes`, `follows`, `subscriptions` tables.

---

## 🧠 2. Recommendation Logic (Controller or Service)

```php
$user = auth()->user();

$tags = DB::table('post_tag')
    ->join('post_views', 'post_views.post_id', '=', 'post_tag.post_id')
    ->where('post_views.user_id', $user->id)
    ->select('post_tag.tag_id', DB::raw('count(*) as score'))
    ->groupBy('post_tag.tag_id')
    ->orderByDesc('score')
    ->pluck('tag_id');

$recommended = Post::whereHas('tags', fn($q) => $q->whereIn('tags.id', $tags))
    ->where('user_id', '!=', $user->id)
    ->latest()
    ->take(12)
    ->get();
```

---

## 🖼️ 3. Blade Example for "You May Like"

```blade
@if($recommended->count())
  <div class="grid grid-cols-3 gap-4">
    @foreach($recommended as $post)
      <x-post-card :post="$post" />
    @endforeach
  </div>
@endif
```

---

## ✅ Optional Enhancements

- Decay old views (>30 days)
- Exclude blocked users/posts
- Combine with "trending" posts logic
- Fuzzy search fallback or MeiliSearch fallback

---

## 🔁 Use Cases

- Feed personalization
- Creator discovery ("similar creators")
- Landing page dynamic content

Inspired by:
- YouTube-style viewer clustering
- Laravel relationship query scoring
- [Meilisearch ranking rules](https://www.meilisearch.com/docs/learn/core_concepts/relevancy/)

