# 🧾 CSV Export Tools

Admins and creators can export data like revenue, subscriptions, posts, and referrals as CSV files.

---

## 📦 1. Controller Example for Admin CSV Exports

```php
use Symfony\Component\HttpFoundation\StreamedResponse;

public function exportUsers()
{
    $response = new StreamedResponse(function () {
        $handle = fopen('php://output', 'w');
        fputcsv($handle, ['ID', 'Name', 'Email', 'Role', 'Joined']);

        User::chunk(200, function ($users) use ($handle) {
            foreach ($users as $user) {
                fputcsv($handle, [
                    $user->id,
                    $user->name,
                    $user->email,
                    $user->role,
                    $user->created_at->toDateString()
                ]);
            }
        });

        fclose($handle);
    });

    $response->headers->set('Content-Type', 'text/csv');
    $response->headers->set('Content-Disposition', 'attachment; filename="users.csv"');
    return $response;
}
```

---

## 📄 2. Blade Button (Admins or Creators)

```blade
<a href="{{ route('admin.export.users') }}" class="btn">⬇️ Export Users</a>
```

---

## 📂 3. Example Routes

```php
Route::middleware(['auth', 'is_admin'])->group(function () {
    Route::get('/admin/export/users', [AdminExportController::class, 'exportUsers'])->name('admin.export.users');
});
```

---

## ✅ Optional Exports

- `exportSubscriptions()` — user, plan, price, start, end
- `exportPayments()` — amount, gateway, user, timestamp
- `exportReferrals()` — referrer, referred, date

---

## 🧰 Tips

- Use Laravel Excel (maatwebsite/excel) for advanced formatting
- Stream output for large datasets
- Add filtering to export subsets (e.g., date ranges)

Inspired by:
- [Laravel Excel](https://laravel-excel.com/)
- [Laravel StreamedResponse](https://laravel.com/docs/responses#streamed-downloads)

