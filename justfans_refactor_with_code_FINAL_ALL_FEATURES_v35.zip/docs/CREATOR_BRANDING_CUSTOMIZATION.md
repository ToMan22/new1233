# 🎨 Creator Branding & Profile Customization

Enable creators to personalize their storefront/profile with branding assets and settings.

---

## 📐 1. Migration

```php
Schema::table('users', function (Blueprint $table) {
    $table->string('banner_image')->nullable();
    $table->string('avatar_image')->nullable();
    $table->text('bio')->nullable();
    $table->string('custom_css')->nullable();
    $table->string('website_url')->nullable();
});
```

---

## 🧾 2. Branding Update Form

```blade
<form method="POST" action="{{ route('creator.profile.update') }}" enctype="multipart/form-data">
  @csrf @method('PUT')
  <label>Banner Image: <input type="file" name="banner_image"></label>
  <label>Avatar Image: <input type="file" name="avatar_image"></label>
  <textarea name="bio" placeholder="Short bio">{{ old('bio', $creator->bio) }}</textarea>
  <input type="url" name="website_url" placeholder="https://..." value="{{ old('website_url', $creator->website_url) }}">
  <button>Update Profile</button>
</form>
```

---

## 🖼️ 3. Public Creator Page (Blade)

```blade
<div class="profile-banner">
  @if($creator->banner_image)
    <img src="{{ asset('storage/' . $creator->banner_image) }}" alt="Banner" />
  @endif
</div>

<div class="creator-info text-center">
  @if($creator->avatar_image)
    <img class="rounded-full w-24 h-24" src="{{ asset('storage/' . $creator->avatar_image) }}" />
  @endif
  <h1>{{ $creator->name }}</h1>
  <p>{{ $creator->bio }}</p>
  <a href="{{ $creator->website_url }}" target="_blank">🌐 Website</a>
</div>
```

---

## 🛠️ 4. Controller Logic (simplified)

```php
if ($request->hasFile('banner_image')) {
    $creator->banner_image = $request->file('banner_image')->store('banners', 'public');
}
if ($request->hasFile('avatar_image')) {
    $creator->avatar_image = $request->file('avatar_image')->store('avatars', 'public');
}
$creator->bio = $request->bio;
$creator->website_url = $request->website_url;
$creator->save();
```

---

## ✅ Optional Enhancements

- Apply `custom_css` in a `<style>` tag for each creator page
- Preview branding before saving
- Store previous branding versions

Inspired by:
- [Gumroad-style custom storefronts](https://gumroad.com/)
- [Laravel Wave by DevDojo](https://github.com/thedevdojo/wave)
