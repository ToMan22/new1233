# 🔔 Real-Time Alerting & Content Approval Queues

Enable real-time alerts for both creators and admins when content is submitted or approved, and structure a moderation queue.

---

## ✅ 1. Post Status & Approval Queue

Ensure `status` field exists on `posts` table:

```php
Schema::table('posts', function (Blueprint $table) {
    $table->enum('status', ['draft', 'pending', 'approved', 'rejected'])->default('draft');
});
```

---

## 📥 2. Creator Flow

**Submit to queue:**

```php
public function submitForApproval(Post $post)
{
    $post->update(['status' => 'pending']);

    Notification::route('mail', 'admin@site.com')
        ->notify(new NewPostSubmitted($post));

    return back()->with('message', 'Submitted for approval.');
}
```

**UI Button:**

```blade
<form action="{{ route('posts.submit', $post->id) }}" method="POST">
  @csrf
  <button class="btn">🚀 Submit for Approval</button>
</form>
```

---

## 📤 3. Admin Approval UI

```php
$queue = Post::where('status', 'pending')->latest()->paginate(20);
```

Blade:

```blade
@foreach($queue as $post)
  <div class="p-2 border">
    <h4>{{ $post->title }}</h4>
    <form method="POST" action="{{ route('admin.posts.approve', $post->id) }}">
      @csrf
      <button name="action" value="approve">✅</button>
      <button name="action" value="reject">❌</button>
    </form>
  </div>
@endforeach
```

---

## 📣 4. Notifications (Email / Database / Broadcast)

**Notification Classes:**

```bash
php artisan make:notification NewPostSubmitted
php artisan make:notification PostApproved
```

Example (`PostApproved`):

```php
public function toMail($notifiable)
{
    return (new MailMessage)
        ->subject('🎉 Your post was approved!')
        ->line("Your post '{$this->post->title}' is now live.");
}
```

---

## 🧠 5. Optional Real-Time (Echo)

Use Laravel Echo + pusher or Ably for:

- Admin gets instant new post in queue
- Creator sees post status change live
- Toast notifications via Livewire or Alpine.js

---

## 🔐 Access Control

- Only creator of post can submit
- Only admin/moderator can approve/reject

---

## Inspired by:

- [Laravel Notifications](https://laravel.com/docs/notifications)
- [Livewire polling/echo](https://laravel-livewire.com/docs)
- [Spatie Email Notifications](https://spatie.be/docs/laravel-backup)

