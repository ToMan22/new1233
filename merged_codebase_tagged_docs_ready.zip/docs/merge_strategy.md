# Merge Strategy

Details strategy used to merge `golive_clean` and `justfans_refactor`.
