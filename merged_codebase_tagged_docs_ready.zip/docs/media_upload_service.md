# MediaUploadService

Handles video upload, preview/thumbnail generation.
