# Trusted Creator Flag

Allows bypassing moderation based on admin-set flag.
