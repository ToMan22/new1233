# Video Model

Supports BunnyCDN, FFmpeg preview, moderation hook.
