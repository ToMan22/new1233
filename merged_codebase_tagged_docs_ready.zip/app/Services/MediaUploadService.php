<?php

// @merged_from: golive_clean services + justfans MediaUpload.md
namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use App\Models\Video;
use FFMpeg;

class MediaUploadService
{
    public function uploadVideo(UploadedFile $file, Video $video): void
    {
        $disk = 'public'; // replace with 'bunnycdn' if configured
        $uuid = Str::uuid();
        $ext = $file->getClientOriginalExtension();
        $filename = "{$uuid}.{$ext}";
        $previewFilename = "{$uuid}_preview.{$ext}";
        $thumbnailFilename = "{$uuid}_thumb.jpg";

        // Store original
        $path = $file->storeAs('videos', $filename, $disk);

        // Generate preview clip (15s)
        $previewPath = "videos/{$previewFilename}";
        $this->makePreview(storage_path("app/{$disk}/{$path}"), storage_path("app/{$disk}/{$previewPath}"), 15);

        // Generate thumbnail
        $thumbnailPath = "videos/{$thumbnailFilename}";
        $this->makeThumbnail(storage_path("app/{$disk}/{$path}"), storage_path("app/{$disk}/{$thumbnailPath}"));

        // Save paths on model
        $video->update([
            'path' => $path,
            'preview_path' => $previewPath,
            'thumbnail_path' => $thumbnailPath,
        ]);
    }

    protected function makePreview(string $input, string $output, int $seconds = 15): void
    {
        $cmd = "ffmpeg -y -i "{$input}" -t {$seconds} -c:v libx264 -preset fast -c:a aac "{$output}"";
        exec($cmd);
    }

    protected function makeThumbnail(string $input, string $output): void
    {
        $cmd = "ffmpeg -ss 00:00:03 -i "{$input}" -frames:v 1 "{$output}"";
        exec($cmd);
    }
}
