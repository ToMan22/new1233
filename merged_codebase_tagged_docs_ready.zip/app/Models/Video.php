<?php

// @merged_from: scaffolded from golive_clean logic + refactored preview strategy
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\ModerationItem;

class Video extends Model
{
    protected $fillable = [
        'user_id',
        'title',
        'description',
        'path',
        'preview_path',
        'thumbnail_path',
        'cdn_url',
        'duration',
        'moderation_status',
        'published_at'
    ];

    protected static function boot()
    {
        parent::boot();

        static::created(function ($video) {
            if ($video->user && $video->user->trusted_creator) return;

            ModerationItem::create([
                'model_type' => self::class,
                'model_id' => $video->id,
                'status' => 'pending',
            ]);
        });
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
