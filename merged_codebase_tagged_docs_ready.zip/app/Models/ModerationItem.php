<?php

// @merged_from: scaffolded per moderation spec in justfans_refactor
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class ModerationItem extends Model
{
    protected $fillable = [
        'model_type', 'model_id', 'status',
        'notes', 'reviewed_by', 'reviewed_at'
    ];

    public function moderatable(): MorphTo
    {
        return $this->morphTo('moderatable', 'model_type', 'model_id');
    }

    public function reviewer()
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }
}
