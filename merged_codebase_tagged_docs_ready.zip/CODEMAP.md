# 🗂️ CODEMAP.md

This map tracks modules, file locations, and which codebase (golive or refactor) is source of truth.

| Feature             | Source           | Key Files                                         | Status  |
|---------------------|------------------|---------------------------------------------------|---------|
| Auth                | golive_clean     | `LoginController.php`, `RegisterController.php`   | TODO    |
| Onboarding          | justfans_refactor| `Livewire/OnboardingWizard.php`, `AdminQueue.php` | ✅ Done |
| Welcome Campaigns   | scaffolded       | `WelcomeCampaign.php`, `Livewire/Admin/*.php`     | ✅ Done |
| Payout System       | golive_clean     | `PayoutController.php`, `CCBillService.php`       | ✅ Partial |
| Video Uploads       | scaffolded       | `Video.php`, `MediaUploadService.php`             | ✅ Done |
| Moderation          | scaffolded       | `ModerationItem.php`, model hooks (Video/Post)    | ✅ Done |
| Image Uploads       | TBD              |                                                   | ⏳ Planned |
| Creator Galleries   | TBD              |                                                   | ⏳ Planned |
| Stripe Billing      | TBD              |                                                   | 💤 Queued |
| Admin Panel         | hybrid           | `Livewire/Admin/*.php`                            | ✅ In progress |
| Compliance (2257)   | golive_clean     | `ComplianceService.php`                           | ✅ Use   |
