# 🗂️ Video Content Categorization

This feature enables classification of videos by tags, categories, and type filters (e.g. free, paid, shortform, NSFW-safe).

---

## 📁 1. Migration: Video Categories & Pivot Table

```php
Schema::create('video_categories', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('slug')->unique();
    $table->timestamps();
});

Schema::create('category_video', function (Blueprint $table) {
    $table->id();
    $table->foreignId('video_id')->constrained()->cascadeOnDelete();
    $table->foreignId('video_category_id')->constrained('video_categories')->cascadeOnDelete();
});
```

---

## 🧠 2. Model Setup

```php
// Video.php
public function categories() {
    return $this->belongsToMany(VideoCategory::class, 'category_video');
}

// VideoCategory.php
public function videos() {
    return $this->belongsToMany(Video::class, 'category_video');
}
```

---

## 🧾 3. Admin Form for Categorization

```blade
<form method="POST" action="{{ route('videos.update.categories', $video) }}">
    @csrf
    @foreach($categories as $category)
      <label>
        <input type="checkbox" name="categories[]" value="{{ $category->id }}"
          @checked($video->categories->contains($category->id))>
        {{ $category->name }}
      </label>
    @endforeach
    <button>Update</button>
</form>
```

---

## 🎯 4. Filter UI on Member Feed

```blade
<form method="GET" action="{{ route('videos.index') }}">
  <select name="category">
    <option value="">All</option>
    @foreach($categories as $category)
      <option value="{{ $category->slug }}" @selected(request('category') == $category->slug)>
        {{ $category->name }}
      </option>
    @endforeach
  </select>
  <button>Filter</button>
</form>
```

In controller:

```php
if ($slug = request('category')) {
  $category = VideoCategory::where('slug', $slug)->firstOrFail();
  $videos = $category->videos()->latest()->paginate();
}
```

---

## 🔒 5. Admin Manager UI

Build Blade CRUD page to:
- Create/edit categories
- Assign ordering/visibility
- Add icons or tags (future: emoji, filters)

---

## ✅ Optional: Tag Grouping or Custom Filters

Group by:
- Length: short / long
- Type: paid / free
- Content flags: NSFW-safe

Store with category meta or in a tag table.

---
