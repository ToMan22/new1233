# 🧾 Payout History, Admin Export, Enhanced Charts & Threshold Alerts

This enhancement builds on the payout logic by adding:

- 📜 Creator payout history table
- 🧑‍💼 Admin earnings export (CSV)
- 🌈 Themed earnings charts
- 📣 Notification system when payouts become available

---

## 1. 📜 Creator Payout History Table

Migration:

```php
$table->decimal('amount');
$table->foreignId('user_id')->constrained();
$table->timestamp('paid_at');
$table->string('reference');
```

Blade:

```blade
<table class="min-w-full text-sm">
  <thead><tr><th>Date</th><th>Amount</th><th>Ref</th></tr></thead>
  <tbody>
    @foreach($user->payouts as $payout)
      <tr>
        <td>{{ $payout->paid_at->toDateString() }}</td>
        <td>${{ number_format($payout->amount, 2) }}</td>
        <td>{{ $payout->reference }}</td>
      </tr>
    @endforeach
  </tbody>
</table>
```

---

## 2. 🧑‍💼 Admin CSV Export

Route:

```php
Route::get('/admin/export/earnings', function () {
    $filename = 'earnings_export_' . now()->toDateString() . '.csv';

    $handle = fopen($path = storage_path("app/$filename"), 'w+');
    fputcsv($handle, ['User ID', 'Amount', 'Date']);

    foreach (\App\Models\Payout::latest()->get() as $payout) {
        fputcsv($handle, [$payout->user_id, $payout->amount, $payout->paid_at]);
    }

    fclose($handle);
    return response()->download($path)->deleteFileAfterSend(true);
})->middleware('can:export-data');
```

---

## 3. 🌈 Themed Chart.js Updates

Use `backgroundColor`, `pointBorderColor`, etc:

```js
backgroundColor: 'rgba(79, 70, 229, 0.2)',
borderColor: '#4f46e5',
pointBorderColor: '#9333ea'
```

To support dark mode:

```js
const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
borderColor: isDark ? '#fff' : '#4f46e5';
```

---

## 4. 📣 Notification Trigger

Laravel Notification:

```php
Notification::route('mail', $user->email)
    ->notify(new PayoutAvailableNotification($payoutAmount));
```

Notification class:

```php
public function toMail($notifiable)
{
    return (new MailMessage)
        ->subject('You Have Earnings Available!')
        ->line("You have $".number_format($this->amount, 2)." ready for payout.")
        ->action('View Dashboard', url('/creator/payouts'));
}
```

This fires when credits exceed $50 (or threshold defined in admin settings).

---
