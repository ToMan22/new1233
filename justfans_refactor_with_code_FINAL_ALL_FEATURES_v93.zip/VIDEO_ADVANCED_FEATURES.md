# 🎬 Advanced Video Enhancements

This guide includes:

1. ✅ Auto-append intro/outro videos
2. 🎯 Tag Analytics & Engagement Heatmaps
3. 🔍 Category Video SEO Schema (JSON-LD)

---

## 1. 🎬 Video Intro/Post-Roll Auto-Addition (FFMPEG)

Add intro/outro to uploaded videos:

```bash
ffmpeg -i intro.mp4 -i content.mp4 -i outro.mp4 \
  -filter_complex "[0:v:0][0:a:0][1:v:0][1:a:0][2:v:0][2:a:0] concat=n=3:v=1:a=1 [v][a]" \
  -map "[v]" -map "[a]" output.mp4
```

Laravel job:

```php
$cmd = "ffmpeg -i $intro -i $video -i $outro ... concat ...";
exec($cmd);
Storage::put("final/$videoName", file_get_contents($output));
```

---

## 2. 🎯 Tag Analytics & Heatmaps

Track tags in `video_tag` pivot:

```php
Schema::create('video_tag', function (Blueprint $table) {
    $table->id();
    $table->foreignId('video_id')->constrained()->cascadeOnDelete();
    $table->foreignId('tag_id')->constrained()->cascadeOnDelete();
    $table->unsignedInteger('clicks')->default(0);
});
```

On frontend clicks:

```php
DB::table('video_tag')
  ->where(['video_id' => $video->id, 'tag_id' => $tag->id])
  ->increment('clicks');
```

Render heatmap via Chart.js or heatmap.js:

```js
// Example for tag popularity
const ctx = document.getElementById("tagChart");
new Chart(ctx, {
  type: "bar",
  data: {
    labels: [...],
    datasets: [{ label: "Tag Clicks", data: [...] }]
  }
});
```

---

## 3. 🔍 SEO Schema for Video

Blade injection (`@section('schema')`):

```blade
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "{{ $video->title }}",
  "description": "{{ $video->excerpt }}",
  "thumbnailUrl": "{{ $video->thumbnail }}",
  "uploadDate": "{{ $video->created_at->toW3cString() }}",
  "contentUrl": "{{ route('videos.watch', $video->slug) }}",
  "publisher": {
    "@type": "Organization",
    "name": "JustFans",
    "logo": {
      "@type": "ImageObject",
      "url": "{{ asset('logo.png') }}"
    }
  }
}
</script>
```

✅ Output only for public/free videos that pass safe-mode check.

---
