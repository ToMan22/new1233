# 📈 Daily Earning Summary Widget (Livewire)

This Livewire widget provides a **creator dashboard module** showing:
- Today's earnings
- Past 7 days summary
- Total lifetime earnings

---

## 📦 Migration Assumption

Earnings are stored on each post:

```php
$table->decimal('earnings', 10, 2)->default(0);
$table->foreignId('user_id')->constrained()->cascadeOnDelete();
```

Alternatively, use a `payments` table with:

```php
$table->decimal('amount');
$table->foreignId('creator_id')->constrained('users');
$table->timestamp('paid_at');
```

---

## ⚙️ Livewire Component

```bash
php artisan make:livewire Creator/EarningSummary
```

### `EarningSummary.php`

```php
use Livewire\Component;
use Carbon\Carbon;

class EarningSummary extends Component
{
    public $today;
    public $week;
    public $total;

    public function mount()
    {
        $user = auth()->user();

        $this->today = $user->posts()->whereDate('created_at', Carbon::today())->sum('earnings');
        $this->week = $user->posts()->whereBetween('created_at', [now()->subDays(7), now()])->sum('earnings');
        $this->total = $user->posts()->sum('earnings');
    }

    public function render()
    {
        return view('livewire.creator.earning-summary');
    }
}
```

---

## 🎨 Blade View (`earning-summary.blade.php`)

```blade
<div class="bg-white rounded shadow p-4">
  <h3 class="text-lg font-bold mb-2">Earnings Overview</h3>
  <div class="grid grid-cols-3 gap-4 text-center">
    <div><p class="text-sm">Today</p><p class="text-xl font-bold">${{ number_format($today, 2) }}</p></div>
    <div><p class="text-sm">Last 7 Days</p><p class="text-xl font-bold">${{ number_format($week, 2) }}</p></div>
    <div><p class="text-sm">All Time</p><p class="text-xl font-bold">${{ number_format($total, 2) }}</p></div>
  </div>
</div>
```

---

## 🧩 Blade Usage

```blade
<livewire:creator.earning-summary />
```

---

## 🔒 Optional: API for Mobile

```php
Route::middleware('auth:sanctum')->get('/api/creator/earnings-summary', function () {
    $user = auth()->user();
    return [
        'today' => $user->posts()->whereDate('created_at', today())->sum('earnings'),
        'week' => $user->posts()->whereBetween('created_at', [now()->subDays(7), now()])->sum('earnings'),
        'total' => $user->posts()->sum('earnings'),
    ];
});
```

---

## 🔁 Enhancement Ideas

- Graph earnings via Chart.js
- Compare periods ("this week vs last week")
- Add payout frequency estimator
