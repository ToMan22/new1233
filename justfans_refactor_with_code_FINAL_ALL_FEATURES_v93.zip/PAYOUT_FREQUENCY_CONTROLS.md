# 🗓️ Payout Frequency Controls (Weekly/Monthly)

This enhancement allows creators to choose their preferred payout cadence.

---

## 🧩 Step 1: Add Frequency to Users Table

```php
$table->enum('payout_frequency', ['weekly', 'monthly'])->default('monthly');
```

---

## ⚙️ Step 2: Update Settings UI

Blade form:

```blade
<form method="POST" action="{{ route('creator.payout.settings.update') }}">
    @csrf
    <select name="payout_frequency" class="form-select">
        <option value="weekly" @selected(auth()->user()->payout_frequency == 'weekly')>Weekly</option>
        <option value="monthly" @selected(auth()->user()->payout_frequency == 'monthly')>Monthly</option>
    </select>
    <button type="submit">Save</button>
</form>
```

Route:

```php
Route::post('/creator/payout/settings', function () {
    request()->validate(['payout_frequency' => 'in:weekly,monthly']);
    auth()->user()->update(['payout_frequency' => request('payout_frequency')]);
    return back()->with('status', 'Saved');
})->name('creator.payout.settings.update');
```

---

## ⏱️ Step 3: Process Based on Frequency

```php
$users = User::whereNotNull('ccbill_user_id')->get();

foreach ($users as $user) {
    $shouldPay = match ($user->payout_frequency) {
        'weekly' => now()->dayOfWeek === 5, // Friday
        'monthly' => now()->day === 28
    };

    if ($shouldPay) {
        // payout logic
    }
}
```

This should run via scheduler:

```php
$schedule->call(function () {
    Artisan::call('payout:process'); // or include inline
})->daily();
```

---

## 🔁 Optional: Admin Override & History View

Admin can:
- Force immediate payout
- Filter users by payout type

Use a similar Blade table + filter UI for admin reporting:

```php
User::where('payout_frequency', 'weekly')->get()
```

---

