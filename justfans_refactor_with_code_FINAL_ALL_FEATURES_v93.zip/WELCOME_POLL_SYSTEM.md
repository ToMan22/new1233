# 🗳️ Welcome Poll System for Onboarded Creators (Livewire)

This module introduces a **Livewire-based Poll System**:
- Enrolled automatically after onboarding
- Linked to creator tags (e.g. "new-creator", "onboarded")
- Supports radio/multi-select with result insights

---

## 📦 1. Models & Migrations

### Create `Poll` and `PollOption` models

```bash
php artisan make:model Poll -m
php artisan make:model PollOption -m
```

### `polls` Migration

```php
$table->id();
$table->string('title');
$table->text('description')->nullable();
$table->string('tag_slug')->nullable(); // Only creators with this tag can view
$table->timestamps();
```

### `poll_options` Migration

```php
$table->id();
$table->foreignId('poll_id')->constrained()->cascadeOnDelete();
$table->string('label');
$table->unsignedInteger('votes')->default(0);
$table->timestamps();
```

---

## 🧩 2. Livewire Components

```bash
php artisan make:livewire WelcomePoll
```

### `WelcomePoll.php`

```php
public Poll $poll;
public $selectedOption;

public function mount()
{
    $this->poll = Poll::where('tag_slug', 'new-creator')->latest()->first();
}

public function vote()
{
    PollOption::where('id', $this->selectedOption)->increment('votes');
    session()->flash('message', 'Thanks for your vote!');
}
```

---

## 🎨 Blade Component

```blade
<div>
    <h2 class="text-xl font-bold">{{ $poll->title }}</h2>
    <p class="text-sm text-gray-500">{{ $poll->description }}</p>

    <form wire:submit.prevent="vote" class="mt-4">
        @foreach($poll->options as $option)
            <label class="block my-2">
                <input type="radio" wire:model="selectedOption" value="{{ $option->id }}">
                {{ $option->label }}
            </label>
        @endforeach

        <button type="submit" class="btn btn-primary mt-2">Vote</button>
    </form>

    @if (session()->has('message'))
        <p class="mt-2 text-green-600">{{ session('message') }}</p>
    @endif
</div>
```

---

## 🧬 3. Auto-Enroll New Creators

```php
$tag = Tag::firstOrCreate(['slug' => 'new-creator'], ['label' => 'New Creator']);
auth()->user()->tags()->syncWithoutDetaching($tag->id);
```

---

## 📊 4. Admin Panel to Create Polls

```bash
php artisan make:livewire Admin/CreatePoll
```

- Form with title, description, `tag_slug`, and dynamic option fields

---

## 🧪 Example Seeding

```php
$poll = Poll::create([
    'title' => 'What do you want from our community?',
    'description' => 'Choose the option that matters most!',
    'tag_slug' => 'new-creator'
]);

$poll->options()->createMany([
    ['label' => 'More guides'],
    ['label' => 'More promo tools'],
    ['label' => 'Better onboarding']
]);
```
