# 🖼️ Theme Gallery with Preview Carousel

Let users browse, preview, and unlock profile themes visually using an interactive Tailwind-powered carousel.

---

## 🧱 1. Extend PremiumTheme Model with Assets

```php
Schema::table('premium_themes', function (Blueprint $table) {
    $table->string('preview_image')->nullable(); // main thumbnail
    $table->string('preview_carousel')->nullable(); // JSON: multiple image paths
});
```

---

## 🎨 2. Blade View with Glide.js Carousel

Install [Glide.js](https://glidejs.com/) or Swiper:

```bash
npm install @glidejs/glide
```

**Blade UI Example:**

```blade
@foreach($premiumThemes as $theme)
  <div class="mb-8 border p-4 rounded">
    <h3 class="text-lg font-bold">{{ $theme->name }}</h3>

    <div class="glide w-full">
      <div class="glide__track" data-glide-el="track">
        <ul class="glide__slides">
          @foreach(json_decode($theme->preview_carousel ?? '[]') as $img)
            <li class="glide__slide">
              <img src="{{ asset($img) }}" class="rounded shadow" />
            </li>
          @endforeach
        </ul>
      </div>
    </div>

    @if(!auth()->user()->premiumThemes->contains($theme))
      <form method="POST" action="{{ route('themes.unlock', $theme) }}" class="mt-2">
        @csrf
        <button class="bg-indigo-600 text-white px-4 py-1 rounded">Unlock for ${{ number_format($theme->price / 100, 2) }}</button>
      </form>
    @else
      <span class="text-green-600 font-semibold">Unlocked</span>
    @endif
  </div>
@endforeach
```

---

## 💾 3. Admin Panel or Seeder to Add Previews

```php
PremiumTheme::create([
  'name' => 'Elegant',
  'class' => 'elegant-theme',
  'price' => 499,
  'preview_image' => 'themes/elegant/thumb.jpg',
  'preview_carousel' => json_encode([
    'themes/elegant/1.jpg',
    'themes/elegant/2.jpg',
    'themes/elegant/3.jpg',
  ]),
]);
```

---

## 🧠 Enhancements

- Hover to auto-preview CSS class in real-time
- Highlight top-selling or trending themes
- Show animated CSS preview using Livewire
