# 💰 Payout History Table, Admin Exports, Chart Themes & Alerts

This feature pack expands creator financial tools with:

- 🧾 Payout history data table (for creators)
- 📤 CSV export option for admin earnings
- 🎨 Enhanced earnings graph (Chart.js theme)
- 🔔 Email/push alert when creator hits payout threshold

---

## 1. 🧾 Payout History Table (Livewire)

```bash
php artisan make:livewire Creator/PayoutHistory
```

### `PayoutHistory.php`

```php
use Livewire\Component;

class PayoutHistory extends Component
{
    public function render()
    {
        $payouts = auth()->user()->payouts()->latest()->paginate(10);
        return view('livewire.creator.payout-history', compact('payouts'));
    }
}
```

### Blade: `payout-history.blade.php`

```blade
<table class="min-w-full bg-white shadow rounded">
  <thead>
    <tr><th>Amount</th><th>Date</th><th>Reference</th></tr>
  </thead>
  <tbody>
    @foreach($payouts as $payout)
    <tr class="border-t">
      <td>${{ $payout->amount }}</td>
      <td>{{ $payout->paid_at->format('Y-m-d') }}</td>
      <td>{{ $payout->reference }}</td>
    </tr>
    @endforeach
  </tbody>
</table>

{{ $payouts->links() }}
```

---

## 2. 📤 Admin CSV Export Route

```php
Route::get('/admin/exports/earnings', function () {
    $csv = fopen('php://output', 'w');
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=earnings_export.csv');
    fputcsv($csv, ['User', 'Date', 'Amount']);

    \App\Models\Payout::with('user')->get()->each(function ($row) use ($csv) {
        fputcsv($csv, [$row->user->name, $row->paid_at, $row->amount]);
    });

    fclose($csv);
    exit;
})->middleware('can:admin');
```

---

## 3. 🎨 Enhanced Chart Theming

Update `Chart.js` config to include gradient fills, tooltips, and more:

```js
options: {
  plugins: {
    tooltip: {
      callbacks: {
        label: ctx => ` $${ctx.raw.toFixed(2)} earned `
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: { color: "#4f46e5" }
    }
  }
}
```

---

## 4. 🔔 Notification When Threshold Hit

```php
if ($user->posts()->sum('earnings') >= 100 && $user->notifications()->where('type', 'PayoutReady')->doesntExist()) {
    $user->notify(new \App\Notifications\PayoutReadyNotification());
}
```

### Notification Class Example:

```php
class PayoutReadyNotification extends Notification implements ShouldQueue
{
    public function via($notifiable) { return ['mail']; }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('You’re Eligible for Payout')
            ->line('You’ve earned over $100. You may now request a payout.');
    }
}
```

---

## 📩 Extend

- Add push (e.g., Pusher or OneSignal) delivery
- Allow admin to filter payouts by tier, user, timeframe
