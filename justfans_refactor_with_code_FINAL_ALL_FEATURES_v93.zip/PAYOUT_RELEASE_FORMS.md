# 📄 Creator Payout Agreement & Release Forms

This module adds:
- 💸 Payout Agreement form (per creator)
- 👥 Guest/Participant Release Form (for shared content)
- 🔒 Secure file uploads + timestamped record
- 🛂 Admin verification interface

---

## 🧩 1. Migration (Agreements + Guest Releases)

```php
Schema::create('payout_agreements', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->string('file_path');
    $table->timestamp('signed_at')->nullable();
    $table->timestamps();
});

Schema::create('release_forms', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained(); // uploader
    $table->string('guest_name');
    $table->string('file_path');
    $table->string('content_reference')->nullable(); // optional post slug/id
    $table->timestamp('signed_at')->nullable();
    $table->timestamps();
});
```

---

## 🧾 2. Blade Form for Creators

```blade
<form action="{{ route('creator.payout.upload') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <label>Payout Agreement PDF:</label>
    <input type="file" name="agreement" accept="application/pdf" required>
    <button type="submit">Upload</button>
</form>
```

Guest form:

```blade
<form action="{{ route('creator.guest.release') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <input type="text" name="guest_name" required placeholder="Guest Name">
    <input type="file" name="release_form" accept="application/pdf" required>
    <button type="submit">Upload Release</button>
</form>
```

---

## 📂 3. Controller Logic

```php
public function uploadPayout(Request $request)
{
    $path = $request->file('agreement')->store('agreements', 'private');
    $request->user()->payoutAgreement()->create([
        'file_path' => $path,
        'signed_at' => now()
    ]);
}
```

```php
public function uploadGuest(Request $request)
{
    $path = $request->file('release_form')->store('guest_releases', 'private');
    $request->user()->releaseForms()->create([
        'file_path' => $path,
        'guest_name' => $request->guest_name,
        'content_reference' => $request->content_reference,
        'signed_at' => now()
    ]);
}
```

---

## 🔐 4. Admin Panel (Simplified Table)

```blade
@foreach($agreements as $a)
<tr>
  <td>{{ $a->user->name }}</td>
  <td><a href="{{ route('admin.download', ['file' => $a->file_path]) }}">Download</a></td>
  <td>{{ $a->signed_at }}</td>
</tr>
@endforeach
```

Add routes, policies, and optional review flag column.

---

## 🛡️ 5. Secure Storage Notes

- Use `Storage::disk('private')` with a custom disk pointing to `storage/app/private`
- Prevent public access via `.htaccess` or NGINX
- Admin downloads use signed routes or policy-checked controllers

---
