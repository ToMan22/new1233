# 🔒 Gated Creator Onboarding, Notifications, and Reward Credits

Extend onboarding to:

- Restrict access to creator tools until onboarding is done
- Notify moderators/admins of new completed creators
- Provide bonus credits upon onboarding finish

---

## 🔐 1. Middleware: Restrict Creator Tools Until Onboarding Is Done

### Create Middleware

```bash
php artisan make:middleware EnsureOnboardingComplete
```

### `EnsureOnboardingComplete.php`

```php
public function handle($request, Closure $next)
{
    if (auth()->check() && auth()->user()->is_creator && !auth()->user()->onboarding_completed) {
        return redirect()->route('creator.onboarding');
    }

    return $next($request);
}
```

### Register in `Kernel.php`

```php
'creator.onboarded' => \App\Http\Middleware\EnsureOnboardingComplete::class,
```

### Use in Routes

```php
Route::middleware(['auth', 'creator.onboarded'])->group(function () {
    Route::get('/creator/dashboard', CreatorDashboardController::class)->name('creator.dashboard');
});
```

---

## 🔔 2. Notify Admins on Completion

### Add Notification

```bash
php artisan make:notification NewCreatorOnboarded
```

### `NewCreatorOnboarded.php`

```php
public function toMail($notifiable)
{
    return (new MailMessage)
        ->subject('🎉 New Creator Onboarded!')
        ->line(auth()->user()->name . ' has completed onboarding.')
        ->action('Review Creator', url('/admin/creators/' . auth()->id()));
}
```

### Trigger Notification on Last Step

```php
Notification::route('mail', 'admin@example.com')
    ->notify(new NewCreatorOnboarded());
```

---

## 💰 3. Reward Credits Upon Completion

### Add to `complete()` in `CreatorOnboardingWizard.php`

```php
auth()->user()->increment('credits', 100); // Add 100 free credits
auth()->user()->update(['onboarding_completed' => true]);
```

Ensure `credits` and `onboarding_completed` are on the `users` table:

```php
$table->integer('credits')->default(0);
$table->boolean('onboarding_completed')->default(false);
```

---

## 🎁 Optional Badge + Notification

```php
auth()->user()->badges()->create([
    'label' => 'Onboarding Champ',
    'slug' => 'onboarding-champ',
    'awarded_at' => now()
]);
```

