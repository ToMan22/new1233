# 💵 Earnings Payout Logic, Chart Insights & Mobile API

This enhancement connects earnings display to:
- 🔗 CCBill Payout (using existing merchant data)
- 📉 Chart.js Trends (week/month)
- 📲 Mobile API endpoint with earnings + payout status

---

## 1. 🔗 Stripe/CCBill Integration Hook

Using [CCBill PHP SDK](https://github.com/MCProHosting/ccbill-php):

### Store Creator's CCBill SubAccount and Pay Info

```php
$table->string('ccbill_subaccount')->nullable();
$table->string('ccbill_client_account')->nullable();
$table->string('ccbill_user_id')->nullable();
$table->timestamp('last_payout_at')->nullable();
```

### Trigger payout flow:
```php
use App\Services\CCBillService;

$payoutAmount = $user->posts()->sum('earnings') - $user->payouts()->sum('amount');

if ($payoutAmount > 50) {
    $status = CCBillService::sendPayout($user, $payoutAmount);
    if ($status === 'success') {
        $user->payouts()->create([
            'amount' => $payoutAmount,
            'paid_at' => now(),
            'reference' => Str::uuid()
        ]);
    }
}
```

---

## 2. 📉 Chart Earnings Trends

Use `Chart.js`:

```blade
<canvas id="earningsChart" width="400" height="100"></canvas>
<script>
fetch('/api/creator/earnings/trends').then(r => r.json()).then(data => {
    new Chart(document.getElementById('earningsChart'), {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Earnings',
                data: data.values,
                fill: true,
                borderColor: '#4f46e5'
            }]
        }
    });
});
</script>
```

### Route:
```php
Route::get('/api/creator/earnings/trends', function () {
    $user = auth()->user();
    $data = $user->posts()
        ->selectRaw('DATE(created_at) as date, SUM(earnings) as total')
        ->groupBy('date')
        ->orderBy('date')
        ->take(30)
        ->get();

    return [
        'labels' => $data->pluck('date'),
        'values' => $data->pluck('total')
    ];
})->middleware('auth:sanctum');
```

---

## 3. 📲 Mobile API Endpoint

```php
Route::middleware('auth:sanctum')->get('/api/creator/summary', function () {
    $user = auth()->user();
    return [
        'tier' => $user->tier,
        'credits' => $user->credits()->sum('amount'),
        'today' => $user->posts()->whereDate('created_at', today())->sum('earnings'),
        'week' => $user->posts()->whereBetween('created_at', [now()->subDays(7), now()])->sum('earnings'),
        'total' => $user->posts()->sum('earnings'),
        'last_payout' => $user->last_payout_at,
    ];
});
```

This provides a dashboard-ready API payload for creator mobile apps.

---
