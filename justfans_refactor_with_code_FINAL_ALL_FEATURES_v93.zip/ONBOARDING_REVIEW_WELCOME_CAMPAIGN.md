# 🎯 Onboarding Completion: Monetization Gating, Admin Review, and Welcome Campaign

Enhance your onboarding system to:
- Require review before monetization unlock
- Let admins approve new creators in a dedicated queue
- Automatically enroll approved creators into a welcome poll or campaign

---

## 🔐 1. Require Admin Review for Monetization Unlock

### Extend `users` Table:

```php
$table->boolean('onboarding_reviewed')->default(false);
```

### Update Onboarding Completion Logic:

```php
auth()->user()->update([
    'onboarding_completed' => true,
    'onboarding_reviewed' => false,
]);
```

### Gate Monetization:

```php
if (!auth()->user()->onboarding_completed || !auth()->user()->onboarding_reviewed) {
    return redirect()->back()->with('error', 'Monetization requires admin approval.');
}
```

---

## 🧾 2. Admin Onboarding Review Queue

### Route & Controller:

```php
Route::middleware('auth', 'admin')->get('/admin/onboarding-queue', [AdminOnboardingQueueController::class, 'index']);
Route::post('/admin/onboarding-review/{user}', [AdminOnboardingQueueController::class, 'approve']);
```

### Controller:

```php
public function index()
{
    $creators = User::where('onboarding_completed', true)
                    ->where('onboarding_reviewed', false)
                    ->get();
    return view('admin.onboarding.queue', compact('creators'));
}

public function approve(User $user)
{
    $user->update(['onboarding_reviewed' => true]);
    // Notify user if needed
    return back()->with('success', 'Creator approved.');
}
```

---

## 🗳️ 3. Auto-Enrollment in Welcome Campaign (Poll/Survey)

### Add in Completion Logic:

```php
$poll = \App\Models\Poll::firstWhere('type', 'welcome');
$poll?->participants()->attach(auth()->id());
```

Or for campaign tagging:

```php
auth()->user()->tags()->attach(Tag::firstWhere('slug', 'welcome-campaign'));
```

### Optional Notification:

```php
auth()->user()->notify(new \App\Notifications\WelcomePollInvitation($poll));
```

---

## ✅ Summary

| Feature                         | Trigger                |
|----------------------------------|------------------------|
| Monetization gating             | Onboarding + admin reviewed |
| Admin onboarding queue          | New onboarded creators |
| Welcome poll enrollment         | Auto after completion  |
