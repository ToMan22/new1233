# ✅ E-Signing + 🔁 Re-verification + 🔒 Blockchain Timestamping

This enhancement adds:

- ✅ HelloSign/Docusign integration for digital signatures
- 🔁 Annual re-verification prompt for legal forms
- 🔒 Blockchain timestamping (using OpenTimestamps or ETH tx hashes)

---

## ✅ HelloSign Integration (Example)

1. Install HelloSign SDK:

```bash
composer require hellosign/hellosign-php-sdk
```

2. Create template via HelloSign admin.

3. Backend logic:

```php
use HelloSign\Client;
use HelloSign\SignatureRequest;

$client = new Client(env('HELLOSIGN_API_KEY'));

$request = new SignatureRequest();
$request->enableTestMode();
$request->setTitle("Payout Agreement");
$request->setSubject("Please sign your creator payout agreement");
$request->addSigner($user->email, $user->name);
$request->addFile(storage_path('app/templates/payout_agreement.pdf'));

$response = $client->sendSignatureRequest($request);

// Save $response->getSignatureRequestId()
```

4. Webhook endpoint (`/webhook/esign`):

```php
if ($event['event']['event_type'] == 'signature_request_signed') {
    $record = PayoutAgreement::where('signature_id', $event['signature_request']['signature_request_id'])->first();
    $record->update(['signed_at' => now(), 'status' => 'signed']);
}
```

---

## 🔁 Periodic Re-verification

Add scheduler logic:

```php
$schedule->call(function () {
    User::whereDate('last_verification', '<', now()->subYear())->each(function ($user) {
        Notification::route('mail', $user->email)->notify(new VerificationRenewalNotice);
    });
})->daily();
```

---

## 🔒 Blockchain Timestamping (e.g., OpenTimestamps)

Use:

```bash
npm install opentimestamps
```

Sign:

```bash
ots stamp payout_agreement.pdf
ots upgrade payout_agreement.ots
ots verify payout_agreement.ots
```

Optionally generate ETH tx hash via smart contract logger (if desired).

---

## Storage Note

Store `.ots` or `.ethproof` beside uploaded file. Append to DB row:

```php
$table->string('blockchain_hash')->nullable();
$table->string('ots_file')->nullable();
```

Display badge for "verified on chain" where available.

---

## Admin Panel Display

- Show verification status
- Signed date
- Re-verify prompt badge if >12mo
- Blockchain proof download

---
