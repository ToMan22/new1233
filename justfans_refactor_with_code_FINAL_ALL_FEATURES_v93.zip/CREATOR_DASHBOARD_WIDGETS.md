# 🎛️ Creator Dashboard Widgets (Tier & Credit Insights)

This feature adds **Livewire-powered creator dashboard widgets** to display:
- Current tier (`starter`, `pro`, `vip`)
- Earned and used credits (visual + numeric)
- Next-tier goal or badge info

---

## ⚙️ Setup

### Migration (if needed):

Ensure `users` table has a `tier` column (default `'starter'`).

Credits assumed tracked in a `credits` table with `amount`, `source`, and `note`.

---

## 🧩 Livewire Component

```bash
php artisan make:livewire Creator/DashboardWidget
```

### `DashboardWidget.php`

```php
use Livewire\Component;

class DashboardWidget extends Component
{
    public $tier;
    public $credits;
    public $nextTier;

    public function mount()
    {
        $user = auth()->user();
        $this->tier = $user->tier ?? 'starter';
        $this->credits = $user->credits()->sum('amount');
        $this->nextTier = match($this->tier) {
            'starter' => 'Pro (1000+ sales)',
            'pro' => 'VIP (5000+ sales)',
            default => 'Max tier reached'
        };
    }

    public function render()
    {
        return view('livewire.creator.dashboard-widget');
    }
}
```

---

## 🎨 Blade View (`dashboard-widget.blade.php`)

```blade
<div class="p-4 bg-white rounded shadow">
    <h2 class="text-xl font-bold mb-2">Account Insights</h2>

    <p><strong>Tier:</strong> {{ ucfirst($tier) }}</p>
    <p><strong>Credits:</strong> {{ $credits }} pts</p>

    <div class="mt-3">
        <label class="text-sm text-gray-500">Next Tier Goal</label>
        <div class="bg-gray-200 rounded-full h-4 mt-1">
            <div class="bg-indigo-600 h-4 rounded-full transition-all"
                 style="width: {{ min(100, $credits / 1000 * 100) }}%"></div>
        </div>
        <p class="text-xs text-gray-400 mt-1">{{ $nextTier }}</p>
    </div>
</div>
```

---

## 🧬 Blade Integration

```blade
<livewire:creator.dashboard-widget />
```

---

## 📌 Optional: API Endpoint for Mobile

```php
Route::middleware('auth:sanctum')->get('/api/creator/insights', function () {
    return [
        'tier' => auth()->user()->tier,
        'credits' => auth()->user()->credits()->sum('amount'),
    ];
});
```
