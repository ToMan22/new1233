# 🧠 Store Selected Theme Temporarily for Onboarding (Session-Based)

Enhance onboarding by remembering the selected theme across page views using Laravel session memory + Livewire.

---

## ✨ 1. Update Livewire Component to Use Session

### `ThemePreviewSwitcher.php`

```php
public function mount()
{
    $this->themes = \App\Models\PremiumTheme::where('active', true)->get();
    $this->selectedTheme = session('theme_preview', $this->themes->first()?->class);
}

public function selectTheme($theme)
{
    $this->selectedTheme = $theme;
    session(['theme_preview' => $theme]);
}
```

---

## 🖼️ 2. Use Session in Other Onboarding Views

For example, in profile setup:

```blade
@php $activeTheme = session('theme_preview', 'default-theme'); @endphp

<div class="@if($activeTheme === 'dark') bg-gray-900 text-white
             @elseif($activeTheme === 'neon') bg-black text-green-400
             @elseif($activeTheme === 'elegant') bg-white text-gray-800
             @else bg-gray-100 text-black @endif p-4 rounded">
  Welcome to your creator dashboard with {{ ucfirst($activeTheme) }} preview!
</div>
```

---

## 🔁 3. Optionally Clear After Onboarding

```php
session()->forget('theme_preview');
```

Or move the value into the user model on profile creation:

```php
auth()->user()->update([
  'theme_preset' => session('theme_preview'),
]);
session()->forget('theme_preview');
```

---

## 🌟 Benefits

- Seamless UX from theme gallery → profile setup
- Creator doesn't have to pick twice
- Fully Livewire-compatible + portable
