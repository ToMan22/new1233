

---

## 🖼️ Theme Gallery with Preview Carousel

- 📘 [Theme Gallery Guide](docs/THEME_GALLERY_PREVIEW_CAROUSEL.md)
  - Preview themes with Tailwind + Glide.js
  - JSON-based image carousels from DB
  - Unlock button embedded in carousel preview


---

## ⚡ Livewire Real-Time Theme Preview

- 📘 [Livewire Theme Preview Guide](docs/LIVEWIRE_THEME_PREVIEW.md)
  - Livewire component to switch and preview themes live
  - Includes dynamic color preview blocks
  - Works with Tailwind class toggling and transitions


---

## 🧠 Theme Selection Memory During Onboarding

- 📘 [Session-Based Theme Memory Guide](docs/LIVEWIRE_THEME_SESSION_PREVIEW.md)
  - Livewire stores selected theme in Laravel session
  - Shared across onboarding pages like profile setup
  - Can later persist to DB and forget from session


---

## 🧭 Creator Onboarding Wizard

- 📘 [Onboarding Wizard Guide](docs/ONBOARDING_WIZARD_INTEGRATION.md)
  - Livewire-powered multi-step onboarding flow
  - Theme preview, profile setup, and agreement steps
  - Uses session theme and persists to database


---

## 🎬 Onboarding Extensions

- 📘 [Onboarding Extensions Guide](docs/ONBOARDING_EXTENSIONS.md)
  - Step-by-step video upload or ID verification
  - Creator intro post and content scheduling
  - Visual progress bar and badge upon wizard completion


---

## 🔒 Gated Onboarding Flow, Admin Notifications, and Rewards

- 📘 [Gated Creator Onboarding, Notifications & Rewards Guide](docs/ONBOARDING_GATED_NOTIFICATIONS_REWARDS.md)
  - Restrict dashboard access until creator finishes onboarding
  - Admin notification on new onboarded creator
  - Bonus credits and badge assignment after successful onboarding


---

## ⚖️ Monetization Gating + Limited Uploads Until Onboarding

- 📘 [Onboarding-Limited Usage + Monetization Rules](docs/ONBOARDING_LIMITED_USAGE_MONETIZATION.md)
  - Creators can't set prices until onboarding is complete
  - Admin-controlled storage cap (e.g. 500MB) enforced pre-onboarding
  - Encourages completion while allowing early-stage creation


---

## 🎯 Onboarding Review Queue & Welcome Campaign Enrollment

- 📘 [Admin Onboarding Review + Welcome Poll Guide](docs/ONBOARDING_REVIEW_WELCOME_CAMPAIGN.md)
  - Monetization gated until admin review complete
  - Admin queue to approve new onboarded creators
  - Auto-enrollment in welcome polls or campaigns


---

## 🗳️ Welcome Poll System (Livewire)

- 📘 [Welcome Poll Module Documentation](docs/WELCOME_POLL_SYSTEM.md)
  - Onboarded creators auto-tagged
  - Livewire component polls with vote capture
  - Admin poll creation support


---

## ✅ Required Expansion Features: Completed

- 📘 [Partial Expansions Completed](docs/PARTIAL_EXPANSIONS_COMPLETED.md)
  - Admin onboarding filter tools
  - Tiered creator upgrade logic
  - AI-based content tag suggestion logic
  - Admin timeline/audit event view
  - Advanced credit issuance per referral or action
  - Sanctum-powered API access scaffold with OpenAPI setup


---

## 🎛️ Creator Dashboard Widgets

- 📘 [Creator Widget Docs](docs/CREATOR_DASHBOARD_WIDGETS.md)
  - Tier + credits display via Livewire
  - Auto-calculated goal to next tier
  - Optional API access for mobile


---

## 📈 Daily Earning Summary Widget

- 📘 [Creator Earnings Summary](docs/CREATOR_EARNINGS_SUMMARY.md)
  - Livewire dashboard module
  - Shows earnings for today, this week, and all time
  - Optional mobile API for summary access


---

## 💵 Earnings + Payout Integration, Trends & API

- 📘 [Payout + Chart.js + API Setup](docs/EARNINGS_PAYOUT_TRENDS_API.md)
  - CCBill payout logic via `ccbill-php`
  - Creator trend chart (30-day line graph)
  - Unified mobile dashboard endpoint (`/api/creator/summary`)


---

## 💰 Payout History, Export, Graph Enhancements & Alerts

- 📘 [Payout Tables + CSV + Chart + Notification](docs/PAYOUT_HISTORY_EXPORT_GRAPH_ALERTS.md)
  - Creator Livewire payout table
  - Admin earnings CSV export route
  - Custom themed earnings graph (Chart.js)
  - Alert when payout threshold is reached


---

## 🧾 Creator Payout History & Admin Export Tools

- 📘 [Earnings Admin & Alert System](docs/EARNINGS_PAYOUT_HISTORY_ADMIN.md)
  - Creator-facing payout ledger table
  - Admin CSV earnings export
  - Chart.js enhanced theming + dark mode
  - Laravel notification when payout thresholds are met


---

## 🗓️ Payout Frequency Controls (Weekly/Monthly)

- 📘 [Payout Frequency Settings](docs/PAYOUT_FREQUENCY_CONTROLS.md)
  - User preference setting for weekly or monthly payout
  - Scheduler-aware logic with Artisan task
  - Admin override support


---

## 📄 Payout & Guest Release Agreement Forms

- 📘 [Payout + Release Forms Setup](docs/PAYOUT_RELEASE_FORMS.md)
  - Creator payout agreement uploader (PDF)
  - Guest/participant release form system
  - Admin review interface + secure storage


---

## 🔏 E-Signature + Verification Trail Enhancements

- 📘 [E-signing, Re-verification, Blockchain Hashing](docs/ESIGN_REVERIFY_BLOCKCHAIN.md)
  - HelloSign/Docusign signature flow
  - Annual re-verification prompt
  - Blockchain timestamping of legal docs


---

## 🎥 Video Protection (Watermarking + Streaming)

- 📘 [Video Streaming Protection & Watermarking](docs/VIDEO_PROTECTION_WATERMARKING.md)
  - Laravel signed video routes
  - Bunny.net secure token URL generation
  - FFMPEG watermarking automation
  - View audit logging


---

## 🗂️ Video Categorization System

- 📘 [Video Categorization Guide](docs/VIDEO_CATEGORIZATION.md)
  - Category + tag relationships for videos
  - Admin + member filter UIs
  - Secure filtering with slugs (no dynamic URLs)


---

## 🎬 Advanced Video Enhancements

- 📘 [Video Advanced Features](docs/VIDEO_ADVANCED_FEATURES.md)
  - FFMPEG post-roll + intro stitching
  - Tag engagement tracking + heatmaps
  - Schema.org JSON-LD video SEO metadata


---

## 🖼️ Smart Thumbnail Generator

- 📘 [Smart Thumbnail Generator](docs/VIDEO_SMART_THUMBNAILS.md)
  - Extract high-entropy frames using FFMPEG
  - Store and attach dynamic thumbnails per upload
  - Upgradeable to face detection or watchpoint analysis
