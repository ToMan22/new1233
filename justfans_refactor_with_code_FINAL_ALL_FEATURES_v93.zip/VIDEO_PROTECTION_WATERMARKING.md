# 🎥 Video Content Protection: Watermarking + Streaming Control

This module introduces watermarking overlays and secure streaming via Bunny.net, AWS CloudFront, or Laravel Streamable + signed URLs.

---

## 🔐 1. Streaming Protection Options

Choose one of the following for secure delivery:

### A. Bunny.net Secure Token

- Set token + secret in Bunny control panel
- Create signed URLs in Laravel:

```php
$token = hash_hmac('sha256', "/videos/$filename", env('BUNNY_SECRET'));
$securedUrl = "https://$pullZone.b-cdn.net/videos/$filename?token=$token";
```

### B. Signed Route via Laravel

```php
$url = URL::temporarySignedRoute(
    'video.stream', now()->addMinutes(15), ['filename' => 'example.mp4']
);
```

Route:

```php
Route::get('/secure/video/{filename}', function ($filename) {
    abort_unless(request()->hasValidSignature(), 403);
    return response()->file(storage_path("app/videos/$filename"));
})->name('video.stream');
```

---

## 💦 2. Watermarking Videos

Install FFMPEG (server or local):

```bash
brew install ffmpeg
```

Add watermark logic (controller or queue):

```php
$videoPath = storage_path("app/raw/$filename");
$output = storage_path("app/videos/watermarked_$filename");

$cmd = "ffmpeg -i $videoPath -i watermark.png -filter_complex \"overlay=10:10\" $output";
exec($cmd);
```

Move the final output into streaming folder after watermark is applied.

---

## 🖥️ 3. Blade + Player.js Integration

```blade
<video controls preload="metadata" poster="{{ $thumbnail }}">
  <source src="{{ $securedUrl }}" type="video/mp4">
</video>
```

Add `@auth` gate to restrict playback on frontend.

---

## 📊 4. Optional: Streaming Logs

Log views using middleware:

```php
Log::info('Video played', [
  'user_id' => auth()->id(),
  'ip' => request()->ip(),
  'video' => $filename
]);
```

Use this to audit abuse, replay volume, or suspicious IPs.

---

## ✅ Tips

- Store watermarked and raw versions separately
- Batch watermark via queue or post-upload job
- Protect routes via Laravel signed URLs or 3rd-party CDN token

---
