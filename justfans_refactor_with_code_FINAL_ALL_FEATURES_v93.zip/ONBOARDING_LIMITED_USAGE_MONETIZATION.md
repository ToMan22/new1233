# ⚖️ Monetization Gated by Onboarding + Limited Hosting for Incomplete Creators

Enable creators to use the platform before finishing onboarding — but only with restricted content usage (e.g., 500MB) and without monetization.

---

## 🛑 1. Limit Monetization to Fully Onboarded Creators

In any monetized content controller (e.g., post creation, product listings):

```php
if (!auth()->user()->onboarding_completed) {
    return redirect()->back()->with('error', 'Complete onboarding to unlock monetization features.');
}
```

In Blade:

```blade
@if(auth()->user()->onboarding_completed)
  <button class="btn-primary">Set Price</button>
@else
  <p class="text-red-500 text-sm">Monetization requires full onboarding.</p>
@endif
```

---

## 📊 2. Limit Content Upload Storage for Incomplete Creators

### Add Admin Control for GB Allowance

#### Migration

```php
$table->integer('onboarding_gb_allowance')->default(500); // In MB
```

#### Settings Seeder or Admin Panel

```php
// settings('onboarding_storage_limit') = 500;
```

### Enforcement in Upload Controller:

```php
if (!auth()->user()->onboarding_completed) {
    $usedStorage = auth()->user()->media()->sum('size'); // e.g. in bytes

    $limit = settings('onboarding_storage_limit') * 1024 * 1024; // MB → bytes

    if ($usedStorage >= $limit) {
        return back()->with('error', 'Upload limit reached. Please complete onboarding to unlock full usage.');
    }
}
```

---

## 🧮 3. Optional Progress Reminder Banner

```blade
@if(!auth()->user()->onboarding_completed)
  <div class="bg-yellow-100 p-3 rounded mb-3 text-sm text-yellow-700">
    <strong>Heads up!</strong> You can only upload {{ settings('onboarding_storage_limit') }}MB of content until you finish onboarding.
    <a href="{{ route('creator.onboarding') }}" class="underline text-yellow-800">Complete onboarding now</a>
  </div>
@endif
```

---

## ✅ Use Cases

| Feature             | Incomplete Onboarding | Complete Onboarding |
|---------------------|-----------------------|----------------------|
| Monetize content    | ❌ Not allowed         | ✅ Allowed            |
| Upload media        | ✅ Limited by GB       | ✅ Unlimited or higher tier |
| Dashboard access    | ✅ Partial             | ✅ Full               |
| Admin alerts        | ❌ No badge            | ✅ Badge + reward     |
