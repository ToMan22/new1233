# ✅ Required Expansions: Completed Scaffold & Implementation Notes

This document outlines the code and guidance to complete the previously unscaffolded or partial expansion features from the core roadmap.

---

## 1. 🧾 Admin Filter Tools for Onboarding Queue

### Controller:
```php
public function index(Request $request)
{
    $query = User::where('onboarding_completed', true)
                 ->where('onboarding_reviewed', false);

    if ($request->filled('role')) {
        $query->where('role', $request->input('role'));
    }

    if ($request->filled('email')) {
        $query->where('email', 'like', '%' . $request->input('email') . '%');
    }

    if ($request->filled('joined')) {
        $query->whereDate('created_at', $request->input('joined'));
    }

    $creators = $query->latest()->paginate(20);
    return view('admin.onboarding.queue', compact('creators'));
}
```

---

## 2. 🎖️ Creator Tier Upgrades

### Migration:
```php
$table->string('tier')->default('starter'); // starter, pro, vip
```

### Tier Promotion Job:
```php
public function handle()
{
    foreach (User::all() as $user) {
        $revenue = $user->posts()->sum('earnings');

        if ($revenue >= 5000) {
            $user->update(['tier' => 'vip']);
        } elseif ($revenue >= 1000) {
            $user->update(['tier' => 'pro']);
        }
    }
}
```

---

## 3. 🧠 AI-based Content Classifier (Tag Auto-Suggester)

### Controller Logic (Mock):
```php
public function suggestTags(Request $request)
{
    $content = $request->input('text');
    $suggested = \App\Services\Classifier::suggestTagsFromText($content);
    return response()->json($suggested);
}
```

Use GPT, HuggingFace or keyword model locally via `spatie/laravel-tags`.

---

## 4. 📆 Admin Timeline View (Audit Trail)

### Migration:
```php
$table->id();
$table->string('event_type');
$table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
$table->json('metadata');
$table->timestamps();
```

### UI Display:
```blade
@foreach($events as $event)
  <div>
    <p>{{ $event->event_type }} on {{ $event->created_at->diffForHumans() }}</p>
    <pre>{{ json_encode($event->metadata, JSON_PRETTY_PRINT) }}</pre>
  </div>
@endforeach
```

---

## 5. 🎁 Advanced Credits System (Referrals & Bonuses)

### Credits Table:
```php
$table->foreignId('user_id')->constrained();
$table->string('source'); // referral, promo, event
$table->integer('amount');
$table->text('note')->nullable();
```

### Usage:
```php
auth()->user()->credits()->create([
    'amount' => 100,
    'source' => 'referral',
    'note' => 'Bonus for signing up a new creator'
]);
```

---

## 6. 🌐 API Access & Docs

Use Laravel Sanctum:

```bash
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
```

### Auth Example:
```php
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
```

Generate tokens via:

```php
$token = $user->createToken('api-access')->plainTextToken;
```

### Docs (Swagger Example):

Install `darkaonline/l5-swagger` for generating OpenAPI docs:
```bash
composer require "darkaonline/l5-swagger"
php artisan vendor:publish --provider="L5Swagger\L5SwaggerServiceProvider"
```

---

