# 🎬 Onboarding Extensions: Video Upload, ID Verification, Intro Content & Progress

Enhance the creator onboarding wizard with optional ID verification, intro media, and visual completion steps.

---

## 📹 1. Video Upload or ID Verification (Step 4)

### Update Component

```php
public $idUpload;

use Livewire\WithFileUploads;
...
public function completeIdStep()
{
    $this->validate([
        'idUpload' => 'required|file|mimes:jpg,png,pdf|max:5120'
    ]);

    $path = $this->idUpload->store('ids', 'public');

    auth()->user()->update(['id_verification_path' => $path]);

    $this->nextStep();
}
```

### Blade Step

```blade
@if($step === 4)
  <h2>Step 4: Upload ID or Verification</h2>
  <input type="file" wire:model="idUpload" />
  @error('idUpload') <span class="text-red-600">{{ $message }}</span> @enderror
  <button wire:click="completeIdStep" class="btn">Next</button>
@endif
```

---

## 📝 2. Introductory Post Content (Step 5)

```php
public $introPost;

public function completeIntroStep()
{
    auth()->user()->introPost()->create([
        'title' => 'Welcome!',
        'body' => $this->introPost,
        'published_at' => now()
    ]);

    $this->nextStep();
}
```

```blade
@if($step === 5)
  <h2>Step 5: Write a short intro post</h2>
  <textarea wire:model="introPost" class="w-full border p-2"></textarea>
  <button wire:click="completeIntroStep" class="btn">Next</button>
@endif
```

---

## 📆 3. Suggested Content Schedule (Step 6)

```blade
@if($step === 6)
  <h2>Step 6: Pick your first post schedule</h2>
  <input type="datetime-local" wire:model="scheduledPost" />
  <button wire:click="nextStep" class="btn">Next</button>
@endif
```

---

## 📊 4. Progress Bar UI (Top of Wizard)

```blade
<div class="w-full bg-gray-300 h-3 mb-4 rounded">
  <div class="bg-indigo-600 h-3 rounded transition-all duration-500"
       style="width: {{ ($step / 6) * 100 }}%"></div>
</div>
```

---

## 🏅 5. Badge Award on Completion

```php
if ($wizardCompleted) {
    auth()->user()->badges()->create([
        'label' => '🎓 Onboarded Creator',
        'slug' => 'onboarded-creator',
        'awarded_at' => now()
    ]);
}
```

---

## 💾 Migration (Badges)

```php
Schema::create('badges', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->onDelete('cascade');
    $table->string('label');
    $table->string('slug')->unique();
    $table->timestamp('awarded_at');
    $table->timestamps();
});
```

