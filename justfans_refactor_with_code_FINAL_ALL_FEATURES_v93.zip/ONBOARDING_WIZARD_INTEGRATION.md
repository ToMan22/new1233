# 🧭 Creator Onboarding Wizard (Livewire + Blade)

Guide new creators through a smooth onboarding flow with theme selection, profile setup, and media intro using Livewire + session memory.

---

## 🧱 1. Livewire Wizard Component

```bash
php artisan make:livewire CreatorOnboardingWizard
```

---

### `CreatorOnboardingWizard.php`

```php
namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Session;

class CreatorOnboardingWizard extends Component
{
    public $step = 1;
    public $theme;
    public $bio = '';
    public $avatar;
    public $agreedToTerms = false;

    public function mount()
    {
        $this->theme = session('theme_preview', 'default-theme');
    }

    public function nextStep()
    {
        $this->step++;
    }

    public function prevStep()
    {
        $this->step--;
    }

    public function complete()
    {
        auth()->user()->update([
            'bio' => $this->bio,
            'theme_preset' => $this->theme,
        ]);

        session()->forget('theme_preview');

        return redirect()->route('dashboard')->with('success', 'Profile created!');
    }

    public function render()
    {
        return view('livewire.creator-onboarding-wizard');
    }
}
```

---

### `creator-onboarding-wizard.blade.php`

```blade
<div>
  @if($step === 1)
    <h2 class="text-lg font-bold mb-2">Step 1: Select Theme</h2>
    @livewire('theme-preview-switcher')
    <button wire:click="nextStep" class="mt-4 bg-indigo-600 text-white px-4 py-2 rounded">Next</button>

  @elseif($step === 2)
    <h2 class="text-lg font-bold mb-2">Step 2: Set Up Profile</h2>
    <input type="text" wire:model="bio" placeholder="Write a short bio..." class="w-full p-2 border rounded mb-2" />
    <button wire:click="prevStep" class="mr-2 text-gray-600">Back</button>
    <button wire:click="nextStep" class="bg-indigo-600 text-white px-4 py-2 rounded">Next</button>

  @elseif($step === 3)
    <h2 class="text-lg font-bold mb-2">Step 3: Confirm</h2>
    <label class="flex items-center">
      <input type="checkbox" wire:model="agreedToTerms" class="mr-2">
      I agree to the terms and conditions
    </label>
    <button wire:click="prevStep" class="mr-2 text-gray-600">Back</button>
    <button wire:click="complete" class="bg-green-600 text-white px-4 py-2 rounded" @disabled(!$agreedToTerms)>Finish</button>
  @endif
</div>
```

---

## 📍 Route in `web.php`

```php
Route::get('/creator/onboarding', \App\Http\Livewire\CreatorOnboardingWizard::class)
    ->middleware(['auth', 'verified'])->name('creator.onboarding');
```

---

## ✅ Benefits

- Fully reactive onboarding
- Modular steps for theme > profile > media
- Easy to extend (upload ID, sign agreement, intro post)

