# ⚡ Livewire-Powered Real-Time Theme Previews

Enable creators to switch between theme previews in real-time without refreshing the page using Livewire.

---

## 🚀 1. Livewire Component: `ThemePreviewSwitcher`

```bash
php artisan make:livewire ThemePreviewSwitcher
```

---

### `ThemePreviewSwitcher.php`

```php
namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\PremiumTheme;

class ThemePreviewSwitcher extends Component
{
    public $selectedTheme;
    public $themes;

    public function mount()
    {
        $this->themes = PremiumTheme::where('active', true)->get();
        $this->selectedTheme = $this->themes->first()?->class;
    }

    public function selectTheme($theme)
    {
        $this->selectedTheme = $theme;
    }

    public function render()
    {
        return view('livewire.theme-preview-switcher');
    }
}
```

---

### `theme-preview-switcher.blade.php`

```blade
<div>
  <div class="flex gap-4 mb-4">
    @foreach($themes as $theme)
      <button wire:click="selectTheme('{{ $theme->class }}')"
              class="px-4 py-1 border rounded {{ $selectedTheme === $theme->class ? 'bg-indigo-600 text-white' : 'bg-white' }}">
        {{ $theme->name }}
      </button>
    @endforeach
  </div>

  <div class="transition-all duration-500 p-4 rounded shadow
    @if($selectedTheme === 'dark') bg-gray-900 text-white
    @elseif($selectedTheme === 'neon') bg-black text-green-400 border-l-4 border-pink-500
    @elseif($selectedTheme === 'elegant') bg-white text-gray-800 shadow-lg
    @else bg-gray-100 text-black @endif">

    <h2 class="text-xl font-bold">Preview: {{ ucfirst($selectedTheme) }} Theme</h2>
    <p>This is a live preview block for your profile theme.</p>
  </div>
</div>
```

---

## 🧩 2. Usage in Blade

```blade
@livewire('theme-preview-switcher')
```

Make sure Livewire is installed:

```bash
composer require livewire/livewire
php artisan livewire:publish --assets
```

---

## 🌟 Optional Upgrades

- Allow preview of profile or gallery layout
- Store previewed theme via session or hidden field
- Add animation between transitions (e.g., `fade-in`, `slide`)
