# 🖼️ Smart Thumbnail Generation (FFMPEG + Heuristics)

Automatically extract meaningful or most representative thumbnails from uploaded videos.

---

## 🧪 Strategy

1. Use FFMPEG to extract frames at intervals.
2. Score each frame by:
   - Entropy (detail-richness)
   - Brightness
   - Face detection (optional)
3. Choose frame with highest score or most engagement time (if tracked).

---

## ⚙️ Setup

Install FFMPEG & OpenCV (optional for face detection):

```bash
sudo apt install ffmpeg
pip install opencv-python scikit-image
```

---

## 🧱 Laravel Job Example (basic entropy scoring)

```php
function getThumbnailCandidate($videoPath) {
    $framesDir = storage_path("app/thumb_frames");
    @mkdir($framesDir, 0755, true);

    // Extract 1 frame every 2s
    exec("ffmpeg -i $videoPath -vf fps=1/2 $framesDir/frame_%03d.jpg");

    $best = null;
    $bestScore = 0;

    foreach (glob("$framesDir/*.jpg") as $frame) {
        $score = image_entropy($frame); // custom helper
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $frame;
        }
    }

    return $best;
}

function image_entropy($path) {
    $img = imagecreatefromjpeg($path);
    $w = imagesx($img); $h = imagesy($img);
    $hist = array_fill(0, 256, 0);

    for ($x = 0; $x < $w; $x++) {
        for ($y = 0; $y < $h; $y++) {
            $rgb = imagecolorat($img, $x, $y);
            $gray = ($rgb >> 16) & 0xFF;
            $hist[$gray]++;
        }
    }

    $total = $w * $h;
    $entropy = 0;
    foreach ($hist as $count) {
        if ($count == 0) continue;
        $p = $count / $total;
        $entropy -= $p * log($p, 2);
    }
    return $entropy;
}
```

---

## 🖼️ Thumbnail Storage

- Save to `storage/app/public/thumbs/`
- Attach to `Video` model `->thumbnail_url`

---

## 🧠 Optional Enhancements

- Use OpenCV face detection
- Pick frame based on longest viewer watch point
- Queue thumbnails for delayed processing

---
