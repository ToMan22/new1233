# 🎯 Creator Referral Tracking System

Track which users were referred by which creators and reward based on signups or purchases.

---

## 🧬 1. Migration

**Create referral codes and referrals tables**

```php
Schema::create('referral_codes', function (Blueprint $table) {
    $table->id();
    $table->foreignId('creator_id')->constrained('users');
    $table->string('code')->unique();
    $table->timestamps();
});

Schema::create('referrals', function (Blueprint $table) {
    $table->id();
    $table->foreignId('referral_code_id')->constrained();
    $table->foreignId('user_id')->constrained(); // The referred user
    $table->timestamps();
});
```

---

## 🧪 2. Middleware for Capturing Referrals

**Store referral code in session if present**

```php
// In web.php
Route::get('/ref/{code}', function ($code) {
    session(['ref_code' => $code]);
    return redirect('/');
});
```

---

## 👤 3. Apply During Signup

**UserController@store or RegistrationController**

```php
if ($refCode = session('ref_code')) {
    $code = ReferralCode::where('code', $refCode)->first();
    if ($code) {
        Referral::create([
            'referral_code_id' => $code->id,
            'user_id' => $newUser->id,
        ]);
    }
}
```

---

## 🎁 4. Creator Dashboard Display

**Show number of users referred and earnings**

```php
$referrals = Referral::whereHas('referralCode', fn($q) =>
    $q->where('creator_id', auth()->id())
)->with('user')->get();
```

---

## 📤 5. Share Link in UI

```blade
<p>Your referral link:</p>
<input type="text" value="{{ url('/ref/' . $creator->referralCode->code) }}" readonly>
```

---

## 🔐 Optional Enhancements

- Add earnings tracking per referral
- Add referral bonuses or levels
- Track UTM with Telescope
- Automatically generate code on creator registration

