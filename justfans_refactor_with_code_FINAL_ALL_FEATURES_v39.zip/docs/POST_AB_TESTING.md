# 🧪 Post-Level A/B Testing

Test variations of content titles, descriptions, thumbnails, or tagsets to measure engagement.

---

## 🧱 1. A/B Test Schema

```php
Schema::create('post_variants', function (Blueprint $table) {
    $table->id();
    $table->foreignId('post_id')->constrained()->onDelete('cascade');
    $table->string('variant_key'); // e.g., 'A', 'B'
    $table->string('title')->nullable();
    $table->text('body')->nullable();
    $table->string('thumbnail')->nullable();
    $table->unsignedInteger('views')->default(0);
    $table->unsignedInteger('clicks')->default(0);
    $table->timestamps();
});
```

---

## 🧪 2. Post Model Relationship

```php
public function variants()
{
    return $this->hasMany(PostVariant::class);
}
```

---

## 🧠 3. Controller Logic to Serve Variant

```php
public function show(Post $post)
{
    $variant = $post->variants()->inRandomOrder()->first() ?? $post;
    $variant->increment('views');

    return view('posts.view', compact('variant', 'post'));
}
```

---

## ✍️ 4. Blade UI

```blade
<h1>{{ $variant->title ?? $post->title }}</h1>
<img src="{{ asset($variant->thumbnail ?? $post->thumbnail) }}">
<p>{{ $variant->body ?? $post->body }}</p>
```

---

## 📊 5. Track Clicks

```php
public function recordClick(PostVariant $variant)
{
    $variant->increment('clicks');
    return redirect()->to($variant->post->url);
}
```

---

## ✅ Optional Enhancements

- Best performer promotion (auto-promote variant with best CTR)
- Laravel Nova or Filament stats widgets
- Scheduled rebalancing (stop poor variants)
- Admin panel for managing variants

Inspired by:
- [Laravel Experiments by Spatie](https://github.com/spatie/laravel-analytics)
- [AB testing via database polymorphism](https://stackoverflow.com/questions/laravel-ab-variants)

