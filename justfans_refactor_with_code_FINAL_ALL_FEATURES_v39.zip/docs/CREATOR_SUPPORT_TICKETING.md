# 🎟️ Creator Support Ticketing System

Enables creators (and optionally fans) to open, reply to, and close support tickets via dashboard.

---

## 🔧 1. Migrations

```php
Schema::create('support_tickets', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->string('subject');
    $table->enum('status', ['open', 'answered', 'closed'])->default('open');
    $table->timestamps();
});

Schema::create('support_replies', function (Blueprint $table) {
    $table->id();
    $table->foreignId('ticket_id')->constrained('support_tickets');
    $table->foreignId('user_id')->constrained(); // admin or creator
    $table->text('message');
    $table->timestamps();
});
```

---

## 💬 2. Blade Views

**Create Ticket**

```blade
<form method="POST" action="{{ route('tickets.store') }}">
  @csrf
  <input type="text" name="subject" placeholder="Subject" required>
  <textarea name="message" required></textarea>
  <button type="submit">Create Ticket</button>
</form>
```

**Ticket Thread**

```blade
<h2>{{ $ticket->subject }}</h2>
@foreach($ticket->replies as $reply)
  <div class="border p-2 my-1">
    <strong>{{ $reply->user->name }}</strong>
    <p>{{ $reply->message }}</p>
  </div>
@endforeach

<form method="POST" action="{{ route('tickets.reply', $ticket) }}">
  @csrf
  <textarea name="message" required></textarea>
  <button type="submit">Reply</button>
</form>
```

---

## 📡 3. Controller Logic

```php
public function store(Request $request)
{
    $ticket = SupportTicket::create([
        'user_id' => auth()->id(),
        'subject' => $request->subject,
    ]);

    $ticket->replies()->create([
        'user_id' => auth()->id(),
        'message' => $request->message,
    ]);

    return redirect()->route('tickets.show', $ticket);
}

public function reply(Request $request, SupportTicket $ticket)
{
    $ticket->replies()->create([
        'user_id' => auth()->id(),
        'message' => $request->message,
    ]);

    $ticket->status = 'answered';
    $ticket->save();

    return back();
}
```

---

## 🔐 4. Routes & Middleware

```php
Route::middleware(['auth'])->group(function () {
  Route::resource('tickets', TicketController::class)->only(['index', 'create', 'store', 'show']);
  Route::post('tickets/{ticket}/reply', [TicketController::class, 'reply'])->name('tickets.reply');
});
```

---

## ✅ Optional Enhancements

- Admin panel for triaging tickets
- Notification/email on reply
- Auto-close after inactivity
- Attachments to replies

Open source examples inspired from:
- [Laravel HelpDesk](https://github.com/milon/laravel-ticket)
- [laravel-notification-channels/webhook](https://github.com/laravel-notification-channels/webhook)

