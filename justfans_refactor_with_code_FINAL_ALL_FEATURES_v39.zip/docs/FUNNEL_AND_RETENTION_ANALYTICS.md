# 📊 Funnel Tracking & Retention Analytics

Track user journey metrics such as onboarding completion, first post/view, repeat visits, and creator conversion.

---

## 🧱 1. Funnel Events Table

```php
Schema::create('user_events', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->onDelete('cascade');
    $table->string('event_type'); // e.g. 'signup', 'view_post', 'first_purchase'
    $table->string('context')->nullable(); // optional: page, post_id, etc.
    $table->timestamp('occurred_at')->useCurrent();
});
```

---

## 🧠 2. Record Events

Hook into various lifecycle events:

```php
event(new FunnelEvent(auth()->id(), 'view_post', ['post_id' => $post->id]));
```

Listener:

```php
public function handle(FunnelEvent $event)
{
    UserEvent::create([
        'user_id' => $event->userId,
        'event_type' => $event->type,
        'context' => json_encode($event->context),
    ]);
}
```

---

## 📈 3. Retention Stats Query

```php
$dailyUsers = UserEvent::selectRaw('DATE(occurred_at) as date, COUNT(DISTINCT user_id) as users')
    ->where('event_type', 'login')
    ->groupBy('date')
    ->orderBy('date')
    ->get();
```

---

## 📉 4. Funnel Drop-Off Report (Simple)

```php
$signup = UserEvent::where('event_type', 'signup')->count();
$viewed = UserEvent::where('event_type', 'view_post')->count();
$paid = UserEvent::where('event_type', 'first_purchase')->count();

return [
    'signup' => $signup,
    'viewed' => $viewed,
    'paid' => $paid,
    'conversion' => round(($paid / $signup) * 100, 2) . '%',
];
```

---

## 📊 5. Admin Blade View (Optional)

```blade
<table>
  <tr><th>Step</th><th>Users</th></tr>
  <tr><td>Signed Up</td><td>{{ $stats['signup'] }}</td></tr>
  <tr><td>Viewed Content</td><td>{{ $stats['viewed'] }}</td></tr>
  <tr><td>Paid</td><td>{{ $stats['paid'] }}</td></tr>
  <tr><td>Conversion</td><td>{{ $stats['conversion'] }}</td></tr>
</table>
```

---

## ✅ Optional Enhancements

- Laravel Nova/Filament widgets
- Time-to-conversion stats
- Visual dashboards (Chart.js, ApexCharts, etc.)
- Drop-off heatmaps

Inspired by:
- [Laravel Events](https://laravel.com/docs/events)
- [Mixpanel/GA-like funnels](https://segment.com)

