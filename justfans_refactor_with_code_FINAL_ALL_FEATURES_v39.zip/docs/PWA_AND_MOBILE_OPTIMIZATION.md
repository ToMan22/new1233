# 📱 PWA & Mobile Performance Optimization

Add Progressive Web App (PWA) features and optimize frontend for speed and reliability.

---

## 🚀 1. Install Laravel PWA Package

```bash
composer require ladumor/laravel-pwa
php artisan vendor:publish --provider="Ladumor\LaravelPwa\PWAServiceProvider"
```

---

## 📄 2. PWA Configuration (`config/laravelpwa.php`)

```php
'name' => 'JustFans',
'short_name' => 'JF',
'theme_color' => '#000000',
'background_color' => '#ffffff',
'display' => 'standalone',
'scope' => '/',
'start_url' => '/',
'icons' => [
  '72x72' => '/images/icons/icon-72x72.png',
  '96x96' => '/images/icons/icon-96x96.png',
  '128x128' => '/images/icons/icon-128x128.png',
  '144x144' => '/images/icons/icon-144x144.png',
  '152x152' => '/images/icons/icon-152x152.png',
  '192x192' => '/images/icons/icon-192x192.png',
  '384x384' => '/images/icons/icon-384x384.png',
  '512x512' => '/images/icons/icon-512x512.png',
],
```

---

## 🧼 3. Frontend Performance Enhancements

- **Tailwind CSS Optimization**
  Ensure production builds:

```bash
npm run build
```

Update `tailwind.config.js`:

```js
content: ["./resources/**/*.blade.php", "./resources/**/*.js", "./resources/**/*.vue"],
```

- **Lazy Loading Images**

```blade
<img loading="lazy" src="{{ asset($image) }}" alt="..." />
```

- **Defer JS**

```blade
<script src="{{ asset('js/app.js') }}" defer></script>
```

---

## 📦 4. Enable Service Workers

Published file: `public/laravel-pwa-sw.js`

Already registered via the PWA package.

---

## 📱 5. iOS & Android Home Screen Testing

- Use Chrome > Add to Home Screen
- Test offline access to key routes
- Confirm icon rendering and splash screen

---

## ✅ Optional Enhancements

- Offline fallback Blade template
- Cache posts/images (with workbox.js)
- Push notifications (OneSignal/Firebase)

Inspired by:
- [ladumor/laravel-pwa](https://github.com/ladumor/laravel-pwa)
- [vite-plugin-pwa](https://vite-pwa-org.netlify.app/)
