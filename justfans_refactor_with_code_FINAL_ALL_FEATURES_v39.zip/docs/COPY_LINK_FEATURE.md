# 🔗 Clipboard Copy Post Link Button

Add a simple, non-NSFW post link sharing button for creators and fans.

---

## 📋 HTML / Blade

```blade
<div class="mt-4">
  <input id="postLink{{ $post->id }}" type="text" value="{{ route('post.view', $post->slug) }}" readonly class="w-full border p-2 rounded text-gray-600 text-sm" />
  <button onclick="copyToClipboard('postLink{{ $post->id }}')" class="bg-blue-600 text-white px-4 py-2 rounded mt-2">📋 Copy Link</button>
</div>
```

---

## ✂️ JS Clipboard Function

Add this to your `app.blade.php` or a JS file:

```html
<script>
  function copyToClipboard(id) {
    const copyText = document.getElementById(id);
    copyText.select();
    copyText.setSelectionRange(0, 99999); // For mobile
    navigator.clipboard.writeText(copyText.value)
      .then(() => alert("Link copied!"))
      .catch(err => console.error("Copy failed", err));
  }
</script>
```

---

## ✅ Optional Styling

- Use Alpine.js for more interactivity
- Add tooltips or animate success
- Hide input field, only show on hover

```blade
<button @click="navigator.clipboard.writeText('{{ route('post.view', $post->slug) }}')">📋 Copy</button>
```

