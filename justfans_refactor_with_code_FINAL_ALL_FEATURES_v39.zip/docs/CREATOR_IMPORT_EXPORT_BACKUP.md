# 🧳 Creator Import/Export & Backup Tools

Allow creators to export or restore their content/data, and admins to bulk-import or backup creator accounts.

---

## 🧾 1. CSV Export for Creators (Self-Service)

```php
public function exportContent()
{
    $user = auth()->user();

    $posts = $user->posts()->with('tags')->get();

    $filename = 'creator_posts_export_' . now()->format('Ymd_His') . '.csv';
    $handle = fopen(storage_path("app/$filename"), 'w');

    fputcsv($handle, ['Title', 'Body', 'Tags', 'Created']);

    foreach ($posts as $post) {
        fputcsv($handle, [
            $post->title,
            strip_tags($post->body),
            $post->tags->pluck('name')->join(', '),
            $post->created_at
        ]);
    }

    fclose($handle);

    return response()->download(storage_path("app/$filename"));
}
```

Add route and Blade button:

```blade
<a href="{{ route('creator.export') }}" class="btn">⬇️ Export My Posts</a>
```

---

## 📥 2. CSV Import for Admin Use

```php
public function importCreators(Request $request)
{
    $file = fopen($request->file('csv')->getRealPath(), 'r');
    while (($data = fgetcsv($file)) !== FALSE) {
        [$name, $email, $username] = $data;
        User::updateOrCreate(
            ['email' => $email],
            ['name' => $name, 'username' => $username, 'role' => 'creator']
        );
    }
    fclose($file);
    return back()->with('status', 'Creators imported!');
}
```

---

## 💾 3. JSON Backup Option

For API-style export/restore:

```php
$posts = $user->posts()->with('tags')->get();
return response()->json($posts);
```

---

## 🔐 4. Access Control

- Only allow authenticated creators to export their data
- Admins only for bulk CSV imports
- Optional signed links for restoring backups

---

## ✅ Optional Features

- Restore button from export file
- Scheduled admin backup of all creator tables
- ZIP bundle for post images/files (via Laravel Filesystem)

Inspired by:
- [Laravel Excel](https://laravel-excel.com/)
- [Laravel Backup](https://spatie.be/docs/laravel-backup)

