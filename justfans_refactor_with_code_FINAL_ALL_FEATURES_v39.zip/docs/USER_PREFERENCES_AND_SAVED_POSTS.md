# 🧠 User Filter Memory & Saved Posts

Enable persistent user filtering preferences and post saving/favoriting system.

---

## 💾 1. User Preferences Table

```php
Schema::create('user_preferences', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->onDelete('cascade');
    $table->json('filters')->nullable(); // e.g. {"age": "21", "ethnicity": "Asian"}
    $table->timestamps();
});
```

---

## 🔖 2. Saved Posts Table

```php
Schema::create('saved_posts', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->onDelete('cascade');
    $table->foreignId('post_id')->constrained()->onDelete('cascade');
    $table->timestamps();
});
```

---

## 🎛️ 3. Storing Filter Preferences

```php
public function saveFilters(Request $request)
{
    $user = auth()->user();
    $filters = $request->only(['ethnicity', 'age', 'content_type']);
    $user->preferences()->updateOrCreate([], ['filters' => json_encode($filters)]);
}
```

Auto-populate filter form:

```blade
@php $prefs = auth()->user()->preferences->filters ?? []; @endphp
<select name="ethnicity">
  <option value="">All</option>
  @foreach(config('feed-filters.ethnicity') as $eth)
    <option value="{{ $eth }}" {{ ($prefs['ethnicity'] ?? '') == $eth ? 'selected' : '' }}>{{ $eth }}</option>
  @endforeach
</select>
```

---

## 💖 4. Save Post Feature (Blade)

```blade
<form method="POST" action="{{ route('posts.save', $post->id) }}">
  @csrf
  <button>💾 Save</button>
</form>
```

**Routes:**

```php
Route::post('/posts/{post}/save', [SaveController::class, 'store'])->name('posts.save');
Route::get('/saved-posts', [SaveController::class, 'index'])->name('posts.saved');
```

**SaveController.php**

```php
public function store(Post $post)
{
    auth()->user()->savedPosts()->syncWithoutDetaching([$post->id]);
    return back()->with('saved', true);
}

public function index()
{
    $saved = auth()->user()->savedPosts()->latest()->paginate(20);
    return view('posts.saved', compact('saved'));
}
```

---

## ✅ Optional Enhancements

- LocalStorage for guest users
- Blade toggle for unsaving
- Recently viewed posts tracking (via middleware or `post_views`)

Inspired by:
- [Spatie Settings](https://github.com/spatie/laravel-settings)
- [Livewire filter syncing](https://laravel-livewire.com/docs/2.x/input-debounce)

