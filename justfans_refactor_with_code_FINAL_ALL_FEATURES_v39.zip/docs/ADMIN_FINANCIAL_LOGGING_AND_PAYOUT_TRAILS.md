# 💰 Admin Financial Logging & Payout Audit Trails

Track all creator financial transactions, withdrawals, and admin audit actions.

---

## 💵 1. Payout Log Table

```php
Schema::create('payout_logs', function (Blueprint $table) {
    $table->id();
    $table->foreignId('creator_id')->constrained('users')->onDelete('cascade');
    $table->decimal('amount', 10, 2);
    $table->enum('method', ['ccbill', 'manual'])->default('ccbill');
    $table->enum('status', ['requested', 'approved', 'paid', 'rejected'])->default('requested');
    $table->timestamp('requested_at')->useCurrent();
    $table->timestamp('paid_at')->nullable();
    $table->text('notes')->nullable();
    $table->timestamps();
});
```

---

## 🧠 2. Model

```php
class PayoutLog extends Model
{
    protected $fillable = ['creator_id', 'amount', 'method', 'status', 'requested_at', 'paid_at', 'notes'];

    public function creator() {
        return $this->belongsTo(User::class, 'creator_id');
    }
}
```

---

## 📋 3. Admin View (Blade)

```blade
<table>
  <tr><th>Creator</th><th>Amount</th><th>Status</th><th>Requested</th></tr>
  @foreach($logs as $log)
    <tr>
      <td>{{ $log->creator->name }}</td>
      <td>${{ $log->amount }}</td>
      <td>{{ ucfirst($log->status) }}</td>
      <td>{{ $log->requested_at->format('Y-m-d') }}</td>
    </tr>
  @endforeach
</table>
```

---

## 🔍 4. Search/Filter

Allow filter by:

- Date range
- Payout status
- Creator ID

```php
$query = PayoutLog::query();

if ($request->status) {
    $query->where('status', $request->status);
}
if ($request->creator) {
    $query->where('creator_id', $request->creator);
}
```

---

## 🔄 5. Admin Approve/Reject Actions

```php
public function updateStatus(PayoutLog $log, $status)
{
    $log->update([
        'status' => $status,
        'paid_at' => $status === 'paid' ? now() : null,
    ]);
}
```

---

## 🧾 6. Optional Enhancements

- Livewire/Filament dashboard
- Export to CSV or integration with accounting tools
- CCBill sync reconciliation logs

Inspired by:
- [Laravel Cashier](https://laravel.com/docs/billing)
- [Finance dashboards (Nova/Filament)](https://filamentphp.com)

