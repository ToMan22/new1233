# 📊 Admin Revenue Analytics Dashboard

Provide a simple interface for admin to track revenue metrics, subscriptions, and creator earnings.

---

## 🧱 1. Migration (Optional for Manual Aggregates)

If needed, add a table to cache daily revenue stats:

```php
Schema::create('daily_revenue_stats', function (Blueprint $table) {
    $table->id();
    $table->date('date')->unique();
    $table->decimal('total_revenue', 10, 2)->default(0);
    $table->decimal('creator_payouts', 10, 2)->default(0);
    $table->timestamps();
});
```

---

## 📈 2. Admin Controller Analytics Logic

```php
public function dashboard()
{
    return view('admin.analytics', [
        'totalRevenue' => Payment::sum('amount'),
        'monthlyRevenue' => Payment::whereMonth('created_at', now()->month)->sum('amount'),
        'creatorPayouts' => Payout::sum('amount'),
        'userCount' => User::count(),
        'topCreators' => User::withSum('payments', 'amount')
                            ->where('role', 'creator')
                            ->orderByDesc('payments_sum_amount')
                            ->take(5)->get(),
    ]);
}
```

---

## 📊 3. Blade Dashboard (`resources/views/admin/analytics.blade.php`)

```blade
<h2>📊 Revenue Overview</h2>
<ul>
  <li><strong>Total Revenue:</strong> ${{ number_format($totalRevenue, 2) }}</li>
  <li><strong>This Month:</strong> ${{ number_format($monthlyRevenue, 2) }}</li>
  <li><strong>Payouts Sent:</strong> ${{ number_format($creatorPayouts, 2) }}</li>
  <li><strong>Registered Users:</strong> {{ $userCount }}</li>
</ul>

<h3>🔥 Top Creators</h3>
@foreach($topCreators as $creator)
  <p>{{ $creator->name }} — ${{ number_format($creator->payments_sum_amount, 2) }}</p>
@endforeach
```

---

## 🛡️ 4. Routes + Access Control

```php
Route::middleware(['auth', 'is_admin'])->group(function () {
    Route::get('/admin/analytics', [AdminController::class, 'dashboard'])->name('admin.analytics');
});
```

Create `is_admin` middleware if needed or gate by role.

---

## ✅ Optional Enhancements

- Show daily/weekly revenue graphs using [Chart.js](https://www.chartjs.org/)
- Cache values or use Laravel Telescope to trace sources
- Export CSV reports

