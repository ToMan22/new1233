# 🎁 Subscription Gifting System

Allow users to gift a paid subscription to another user.

---

## 📐 1. Migration

**Gifts Table**

```php
Schema::create('gift_subscriptions', function (Blueprint $table) {
    $table->id();
    $table->foreignId('giver_id')->constrained('users');
    $table->foreignId('receiver_id')->constrained('users');
    $table->foreignId('plan_id')->constrained('subscription_plans');
    $table->timestamp('starts_at')->nullable();
    $table->timestamp('ends_at')->nullable();
    $table->boolean('redeemed')->default(false);
    $table->timestamps();
});
```

---

## 🧾 2. Gift Form (Blade)

```blade
<form method="POST" action="{{ route('gifts.send') }}">
  @csrf
  <input type="email" name="receiver_email" placeholder="Recipient Email" required>
  <select name="plan_id">
    @foreach($plans as $plan)
      <option value="{{ $plan->id }}">{{ $plan->name }} - ${{ $plan->price }}</option>
    @endforeach
  </select>
  <button type="submit">Send Gift</button>
</form>
```

---

## 📤 3. GiftController Logic

```php
public function send(Request $request)
{
    $recipient = User::firstOrCreate(['email' => $request->receiver_email]);

    GiftSubscription::create([
        'giver_id' => auth()->id(),
        'receiver_id' => $recipient->id,
        'plan_id' => $request->plan_id,
        'starts_at' => now(),
        'ends_at' => now()->addMonth(),
    ]);

    // Notify recipient, optionally send email
    return back()->with('message', 'Gift sent!');
}
```

---

## 📥 4. Recipient Redemption View

```blade
@if(!$gift->redeemed)
<form method="POST" action="{{ route('gifts.redeem', $gift) }}">
  @csrf
  <button class="btn">Activate Gift</button>
</form>
@endif
```

---

## ✅ Optional

- Show badge to users with gifted subscriptions
- Add gifting limits or expiry
- Use events to trigger notifications or bonus rewards

