# 📢 Social Sharing Tools (SFW Only)

Provide secure, shareable content URLs while ensuring no NSFW content is exposed on social platforms.

---

## 🛡️ NSFW Flag in Posts Table

Add an `is_nsfw` boolean to posts.

**Migration**
```php
Schema::table('posts', function (Blueprint $table) {
    $table->boolean('is_nsfw')->default(false);
});
```

**Post Model**
```php
protected $casts = [
    'is_nsfw' => 'boolean',
];
```

---

## 🔗 Social Sharing Blade Snippet

Only display sharing buttons for non-NSFW content:

```blade
@if (!$post->is_nsfw)
<div class="flex space-x-2 mt-4">
    <a href="https://twitter.com/intent/tweet?url={{ urlencode(route('post.view', $post->slug)) }}&text={{ urlencode($post->title) }}" target="_blank" rel="noopener" class="text-blue-500 underline">Share on X</a>

    <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(route('post.view', $post->slug)) }}" target="_blank" rel="noopener" class="text-blue-700 underline">Facebook</a>

    <a href="https://www.reddit.com/submit?url={{ urlencode(route('post.view', $post->slug)) }}&title={{ urlencode($post->title) }}" target="_blank" rel="noopener" class="text-orange-500 underline">Reddit</a>
</div>
@endif
```

---

## 🖼️ Safe Preview Image

To avoid NSFW leaks:

- Store a separate `preview_image_url` that’s always SFW
- Use for social `<meta property="og:image">`

**Example in Blade or layout**
```blade
<meta property="og:image" content="{{ $post->preview_image_url }}">
```

---

## ✋ Admin Workflow to Flag NSFW

Ensure admin or creator can toggle:

```blade
<label>
  <input type="checkbox" name="is_nsfw" {{ $post->is_nsfw ? 'checked' : '' }}>
  Mark as NSFW (not shareable)
</label>
```

---

## ✅ Optional Enhancements

- Track shares using Laravel Telescope or custom metrics
- Add UTM tracking to URLs
- Add “Copy link” to clipboard option for creators
