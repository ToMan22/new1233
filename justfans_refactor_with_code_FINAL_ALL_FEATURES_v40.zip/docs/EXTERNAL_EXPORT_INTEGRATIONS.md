# 📦 External Export Integrations (S3, BigQuery)

Enable scheduled exports or admin-triggered dumps to cloud storage or analytics destinations.

---

## ☁️ 1. Export Targets

- **S3 (AWS / Wasabi / DigitalOcean Spaces)**
- **BigQuery (Google Cloud Platform)**

---

## 🗂️ 2. Scheduled Export Job Example

**Command:**

```bash
php artisan make:command ExportPostsToS3
```

**Handler:**

```php
public function handle()
{
    $filename = 'exports/posts_' . now()->format('Ymd_His') . '.csv';
    $path = storage_path('app/' . $filename);

    $file = fopen($path, 'w');
    fputcsv($file, ['id', 'title', 'creator', 'created_at']);

    Post::with('user')->chunk(500, function($posts) use ($file) {
        foreach ($posts as $post) {
            fputcsv($file, [$post->id, $post->title, $post->user->name, $post->created_at]);
        }
    });
    fclose($file);

    Storage::disk('s3')->put($filename, file_get_contents($path));
    Log::info("Exported posts to S3: {$filename}");
}
```

---

## 🧪 3. Test Export Locally

```bash
php artisan export:posts-to-s3
```

Verify in `storage/logs/laravel.log` and your S3 bucket.

---

## 📊 4. BigQuery Export (Via Laravel or Python)

Use `maatwebsite/excel` or queue → GCS:

```bash
composer require maatwebsite/excel
```

```php
Excel::store(new PostsExport, 'posts.xlsx', 'gcs');
```

BigQuery loads via Cloud Scheduler + GCS file.

---

## 🔄 5. Admin Trigger UI (Optional)

```blade
<form method="POST" action="{{ route('exports.posts.s3') }}">
  @csrf
  <button class="btn btn-primary">📤 Export Posts to S3</button>
</form>
```

Route:

```php
Route::post('exports/posts/s3', [ExportController::class, 'exportPostsToS3']);
```

---

## ✅ Optional Enhancements

- Encrypt CSV before upload
- Add export logs table
- Export daily/weekly by job scheduler
- Include analytics data and user events

Inspired by:
- [Laravel Excel](https://laravel-excel.com/)
- [Laravel filesystem with S3](https://laravel.com/docs/filesystem)
- [Google BigQuery load](https://cloud.google.com/bigquery/docs/loading-data)

