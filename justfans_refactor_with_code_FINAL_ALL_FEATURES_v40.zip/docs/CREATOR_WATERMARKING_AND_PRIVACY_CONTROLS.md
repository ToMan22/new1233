# 🔒 Creator Watermarking & Privacy Controls

Add watermark overlays and access controls to protect creators’ image/video content and digital rights.

---

## 🖼️ 1. Image Watermarking (Laravel Intervention Image)

### Composer Install:

```bash
composer require intervention/image
```

### Example Logic:

```php
use Intervention\Image\Facades\Image;

public function watermarkImage($originalPath, $watermarkPath, $outputPath)
{
    $img = Image::make($originalPath);
    $watermark = Image::make($watermarkPath)->opacity(40);

    $img->insert($watermark, 'bottom-right', 10, 10);
    $img->save($outputPath);
}
```

Trigger this on upload or periodically for public-facing content.

---

## 🔐 2. Privacy Settings Table

```php
Schema::create('post_privacy_settings', function (Blueprint $table) {
    $table->id();
    $table->foreignId('post_id')->constrained()->onDelete('cascade');
    $table->boolean('visible_to_members')->default(true);
    $table->boolean('visible_to_guests')->default(false);
    $table->boolean('prevent_screenshots')->default(false); // optional
    $table->boolean('blur_preview')->default(false);
    $table->timestamps();
});
```

---

## 🧾 3. Admin Privacy Controls (Blade UI)

```blade
<form method="POST" action="{{ route('posts.privacy.update', $post) }}">
  @csrf @method('PUT')
  <label><input type="checkbox" name="visible_to_members" value="1" {{ $privacy->visible_to_members ? 'checked' : '' }}> Members only</label>
  <label><input type="checkbox" name="blur_preview" value="1" {{ $privacy->blur_preview ? 'checked' : '' }}> Blur Preview</label>
  <button class="btn btn-primary">💾 Save Privacy</button>
</form>
```

---

## 🔒 4. Blur CSS for Previews

```blade
@if($post->privacy->blur_preview)
  <div class="filter blur-md transition hover:blur-0">
    <img src="{{ $post->image_url }}">
  </div>
@else
  <img src="{{ $post->image_url }}">
@endif
```

---

## 📼 5. Video/Stream Watermark Notes

Use FFmpeg:

```bash
ffmpeg -i input.mp4 -i watermark.png -filter_complex "overlay=W-w-10:H-h-10" output.mp4
```

Or use Bunny Stream watermarking (via Bunny.net panel or Stream API).

---

## ✅ Optional Features

- Auto-apply watermark on upload
- IP restrictions / HLS token protection
- Member-specific watermark (for leaks)
- Screenshot-detection JS + blur fallback

Inspired by:
- [Intervention Image Docs](http://image.intervention.io/)
- [FFmpeg Watermarking](https://trac.ffmpeg.org/wiki/HowToBurnSubtitlesIntoVideo)

