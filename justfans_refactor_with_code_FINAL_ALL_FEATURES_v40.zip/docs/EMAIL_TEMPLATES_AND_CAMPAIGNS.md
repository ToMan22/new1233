# 📧 Email Templates & Campaign Integration

Enable reusable email templates and creator/admin-triggered email campaigns.

---

## ✉️ 1. Mailable Class Example

```bash
php artisan make:mail NewSubscriberNotification
```

```php
class NewSubscriberNotification extends Mailable {
    use Queueable, SerializesModels;
    public $subscriber;

    public function __construct(User $subscriber) {
        $this->subscriber = $subscriber;
    }

    public function build() {
        return $this->subject("🎉 You have a new subscriber!")
            ->view('emails.new-subscriber');
    }
}
```

---

## 📄 2. Email Blade Template (`resources/views/emails/new-subscriber.blade.php`)

```blade
<h1>Hi {{ $subscriber->name }},</h1>
<p>Thanks for subscribing to {{ $creator->name }}!</p>
<p>Check out your exclusive content now 🚀</p>
```

---

## 🗓️ 3. Creator Campaign Email Form

```blade
<form method="POST" action="{{ route('campaign.send') }}">
  @csrf
  <input type="text" name="subject" placeholder="Subject">
  <textarea name="body" placeholder="Message to subscribers"></textarea>
  <button>Send Campaign</button>
</form>
```

---

## 📨 4. CampaignController (Simplified)

```php
public function send(Request $request) {
    $subscribers = auth()->user()->subscribers;

    foreach ($subscribers as $subscriber) {
        Mail::to($subscriber->email)->queue(new CreatorCampaign($request->subject, $request->body));
    }

    return back()->with('success', 'Campaign sent!');
}
```

---

## 🔄 5. Dynamic Campaign Template

```php
class CreatorCampaign extends Mailable {
    public function __construct(public $subject, public $body) {}

    public function build() {
        return $this->subject($this->subject)
                    ->view('emails.creator-campaign')
                    ->with(['body' => $this->body]);
    }
}
```

---

## ✅ Optional Enhancements

- WYSIWYG email body editor (Trix or TinyMCE)
- Unsubscribe management via tokens
- View metrics with Laravel Telescope
- Use Mailgun/Resend/Postmark or Brevo for delivery

Inspired by:
- [Laravel Mailables](https://laravel.com/docs/12.x/mail)
- [Mailcoach](https://github.com/spatie/mailcoach)
- [Laravel Newsletter](https://github.com/spatie/laravel-newsletter)

