# 🔐 Audit Logging & Permission Controls

This system helps track changes by users/admins and restrict features via roles.

---

## 🛡️ 1. Role-Based Permissions

**Add to Users Table**

```php
Schema::table('users', function (Blueprint $table) {
    $table->string('role')->default('member'); // or 'creator', 'admin'
});
```

**Route Example**

```php
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/settings', fn() => view('admin.settings'));
});
```

**Create Role Middleware (`app/Http/Middleware/RoleMiddleware.php`)**

```php
public function handle($request, Closure $next, $role)
{
    if (auth()->user()?->role !== $role) {
        abort(403);
    }
    return $next($request);
}
```

**Register Middleware**

In `app/Http/Kernel.php`:

```php
'role' => \App\Http\Middleware\RoleMiddleware::class,
```

---

## 🧾 2. Audit Logging System

**Audit Table**

```php
Schema::create('audit_logs', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->nullable()->constrained();
    $table->string('action');
    $table->text('details')->nullable();
    $table->ipAddress('ip')->nullable();
    $table->timestamps();
});
```

**Audit Helper Trait**

```php
trait LogsActivity
{
    public function log($action, $details = null)
    {
        \App\Models\AuditLog::create([
            'user_id' => auth()->id(),
            'action' => $action,
            'details' => $details,
            'ip' => request()->ip(),
        ]);
    }
}
```

**Example Usage**

```php
$this->log('Deleted Post', 'Post ID: ' . $post->id);
```

---

## 📊 Admin Audit Viewer

```blade
@foreach($logs as $log)
  <div>
    <strong>{{ $log->action }}</strong>
    <small>{{ $log->created_at->diffForHumans() }}</small>
    <p>{{ $log->details }}</p>
  </div>
@endforeach
```

---

## ✅ Optional Enhancements

- Track login/logout
- Laravel Telescope or Spatie Activity Log alternative
- CSV export of audits
- Granular permission gates (e.g. `can('edit-posts')`)

Inspired by:
- [spatie/laravel-permission](https://github.com/spatie/laravel-permission)
- [owen-it/laravel-auditing](https://github.com/owen-it/laravel-auditing)

