# 🧼 Admin Bulk Moderation & Content Archiving

Provide admins the ability to perform bulk moderation actions and archive content for storage or compliance.

---

## 🗂️ 1. Add Post Status and Archive Fields

```php
Schema::table('posts', function (Blueprint $table) {
    $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
    $table->boolean('archived')->default(false);
});
```

---

## 📋 2. Admin Bulk Action Form

**Blade UI:**

```blade
<form method="POST" action="{{ route('admin.posts.bulk-action') }}">
  @csrf
  <table>
    @foreach($posts as $post)
      <tr>
        <td><input type="checkbox" name="selected[]" value="{{ $post->id }}"></td>
        <td>{{ $post->title }}</td>
      </tr>
    @endforeach
  </table>

  <select name="action">
    <option value="approve">✅ Approve</option>
    <option value="reject">❌ Reject</option>
    <option value="archive">📦 Archive</option>
    <option value="delete">🗑️ Delete</option>
  </select>

  <button class="btn">Apply</button>
</form>
```

---

## 🧠 3. AdminController Logic

```php
public function bulkAction(Request $request)
{
    $postIds = $request->selected ?? [];
    $action = $request->action;

    $query = Post::whereIn('id', $postIds);

    match($action) {
        'approve' => $query->update(['status' => 'approved']),
        'reject' => $query->update(['status' => 'rejected']),
        'archive' => $query->update(['archived' => true]),
        'delete' => $query->delete(),
        default => null
    };

    return back()->with('message', 'Bulk action applied.');
}
```

---

## 📦 4. Archived Content Handling

- Filter `Post::where('archived', false)` in frontend
- Admin toggle to show archived items
- Restore button for unarchiving (`archived = false`)

---

## ✅ Optional Enhancements

- Livewire component for reactive table
- Reason-for-rejection notes
- CSV export for archived post logs
- Auto-archive old content (>X months)

Inspired by:
- [Laravel Nova resource actions](https://nova.laravel.com/docs)
- [Filament table bulk actions](https://filamentphp.com)

