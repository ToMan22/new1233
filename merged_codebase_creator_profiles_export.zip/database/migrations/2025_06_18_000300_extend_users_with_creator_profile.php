<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('users', function (Blueprint $table) {
            $table->string('region')->nullable();
            $table->string('ethnicity')->nullable();
            $table->string('body_type')->nullable();
            $table->string('genre')->nullable();
            $table->string('pronouns')->nullable();
            $table->json('style_tags')->nullable();
        });
    }

    public function down(): void {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['region', 'ethnicity', 'body_type', 'genre', 'pronouns', 'style_tags']);
        });
    }
};
