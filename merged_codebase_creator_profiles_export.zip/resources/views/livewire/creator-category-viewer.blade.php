@extends('layouts.app')

@section('meta')
    <title>{{ $combination->label }} | Creator Category</title>
    <meta name="description" content="Discover creators who match '{{ $combination->label }}'">
@endsection

@section('content')
<div class="max-w-6xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">🎭 {{ $combination->label }}</h1>

    @if($creators->isEmpty())
        <div class="bg-yellow-100 text-yellow-800 p-4 rounded">No creators found for this profile.</div>
    @else
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            @foreach($creators as $creator)
                <div class="border p-4 rounded shadow bg-white">
                    <h3 class="font-semibold">{{ $creator->name }}</h3>
                    <p class="text-sm text-gray-500">
                        {{ $creator->region }}, {{ $creator->ethnicity }}<br>
                        {{ $creator->body_type }}, {{ $creator->genre }}
                    </p>
                </div>
            @endforeach
        </div>
    @endif
</div>
@endsection
