@extends('layouts.app')


@section('meta')
    <title>{{ $combination->label }} | Video Category</title>
    <meta name="description" content="Explore videos related to '{{ $combination->label }}'">
@endsection

@section('content')
<div class="max-w-6xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">🎯 {{ $combination->label }}</h1>

    @if($videos->isEmpty())
        <div class="p-4 bg-yellow-100 text-yellow-800 rounded">
            No videos found for this category.
        </div>
    @else
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            @foreach($videos as $video)
                <div class="border p-4 rounded shadow-sm bg-white">
                    <h3 class="font-semibold">{{ $video->title }}</h3>
                    @if($video->preview_url)
                        <video src="{{ $video->preview_url }}" class="w-full mt-2" controls muted></video>
                    @endif
                </div>
            @endforeach
        </div>
    @endif
</div>
@endsection
