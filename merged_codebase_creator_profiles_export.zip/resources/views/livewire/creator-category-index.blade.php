@extends('layouts.app')

@section('meta')
    <title>All Creator Categories</title>
    <meta name="description" content="Browse creator categories based on appearance, genre, and profile attributes.">
@endsection

@section('content')
<div class="max-w-6xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">🎨 All Creator Categories</h1>

    @if($categories->isEmpty())
        <p class="text-gray-500">No creator categories yet.</p>
    @else
        <ul class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            @foreach($categories as $cat)
                <li class="p-4 bg-white border rounded shadow hover:bg-gray-50">
                    <a href="{{ route('creators.category', $cat->slug) }}" class="block font-semibold text-lg">
                        {{ $cat->label }}
                    </a>
                    <p class="text-sm text-gray-600 mt-1">Used {{ $cat->count }} time(s)</p>
                </li>
            @endforeach
        </ul>
    @endif
</div>
@endsection
