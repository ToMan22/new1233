@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto p-6">
    <h2 class="text-2xl font-bold mb-4">🧑 Update Profile</h2>

    <form wire:submit.prevent="save" class="space-y-4">
        <input type="text" wire:model="region" placeholder="Region" class="w-full p-2 border rounded">
        <input type="text" wire:model="ethnicity" placeholder="Ethnicity" class="w-full p-2 border rounded">
        <input type="text" wire:model="body_type" placeholder="Body Type" class="w-full p-2 border rounded">
        <input type="text" wire:model="genre" placeholder="Genre" class="w-full p-2 border rounded">
        <input type="text" wire:model="pronouns" placeholder="Pronouns" class="w-full p-2 border rounded">
        <textarea wire:model="style_tags" placeholder="Style Tags (comma separated)" class="w-full p-2 border rounded"></textarea>
        <button class="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
    </form>

    @if (session()->has('message'))
        <div class="mt-4 p-2 bg-green-100 text-green-800 rounded">{{ session('message') }}</div>
    @endif
</div>
@endsection
