@extends('layouts.app')


@section('meta')
    <title>All Video Categories</title>
    <meta name="description" content="Browse all curated video categories based on tag combinations.">
@endsection

@section('content')
<div class="max-w-6xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">📚 All Categories</h1>

    @if($categories->isEmpty())
        <p class="text-gray-500">No categories available.</p>
    @else
        <ul class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            @foreach($categories as $cat)
                <li class="p-4 bg-white border rounded shadow hover:bg-gray-50">
                    <a href="{{ route('categories.show', $cat->slug) }}" class="block font-semibold text-lg">
                        {{ $cat->label }}
                    </a>
                    <p class="text-sm text-gray-600 mt-1">Used {{ $cat->count }} time(s)</p>
                </li>
            @endforeach
        </ul>
    @endif
</div>
@endsection
