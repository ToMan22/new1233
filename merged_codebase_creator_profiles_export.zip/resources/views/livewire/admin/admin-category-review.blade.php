@extends('layouts.admin.app')

@section('content')
<div class="p-6 max-w-6xl mx-auto">
    <h2 class="text-2xl font-bold mb-4">📊 Review Tag Combos</h2>
    <label class="block mb-4">
        <input type="checkbox" wire:model="publishedOnly"> Show only published
    </label>
    <table class="w-full table-auto border-collapse">
        <thead>
            <tr class="bg-gray-200 text-left">
                <th class="p-2">Label</th>
                <th class="p-2">Tags</th>
                <th class="p-2">Approved</th>
                <th class="p-2">Published</th>
                <th class="p-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($combinations as $combo)
                <tr class="border-t">
                    <td class="p-2">{{ $combo->label }}</td>
                    <td class="p-2 text-sm text-gray-600">{{ implode(', ', $combo->tag_ids) }}</td>
                    <td class="p-2">{{ $combo->is_approved ? '✅' : '❌' }}</td>
                    <td class="p-2">{{ $combo->is_published ? '📢' : '🔒' }}</td>
                    <td class="p-2 space-x-2">
                        <button wire:click="approve({{ $combo->id }})" class="text-blue-600">Approve</button>
                        <button wire:click="togglePublish({{ $combo->id }})" class="text-green-600">Toggle Publish</button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
