@extends('layouts.admin.app')

@section('content')
<div class="p-6 max-w-4xl mx-auto">
    <h2 class="text-xl font-bold mb-4">🖼 Manage Galleries</h2>
    <form wire:submit.prevent="save" class="space-y-3">
        <input type="text" wire:model="title" placeholder="Title" class="w-full p-2 border rounded">
        <select wire:model="selectedTags" multiple class="w-full p-2 border rounded">
            @foreach($allTags as $tag)
                <option value="{{ $tag->id }}">{{ $tag->name }}</option>
            @endforeach
        </select>
        <button class="px-4 py-2 bg-green-600 text-white rounded">Save</button>
    </form>
    <hr class="my-4">
    <ul>
        @foreach($galleries as $gallery)
            <li>{{ $gallery->title }} ({{ $gallery->tags->pluck('name')->join(', ') }})</li>
        @endforeach
    </ul>
</div>
@endsection
