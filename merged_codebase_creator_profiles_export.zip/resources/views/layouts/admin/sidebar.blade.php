<aside class="w-64 bg-white shadow-md">
    <ul class="p-4 space-y-2">
        <li>
            <a href="{{ route('admin.dashboard') }}" class="block px-4 py-2 hover:bg-gray-100">
                🏠 Dashboard
            </a>
        </li>
        <li>
            <a href="{{ route('admin.videos') }}" class="block px-4 py-2 hover:bg-gray-100">
                🎬 Manage Videos
            </a>
        </li>
        <li>
            <a href="{{ route('admin.galleries') }}" class="block px-4 py-2 hover:bg-gray-100">
                🖼 Manage Galleries
            </a>
        </li>
        <li>
            <a href="{{ route('admin.categories') }}" class="block px-4 py-2 hover:bg-gray-100">
                📂 Manage Categories
            </a>
        </li>
        <li>
            <a href="{{ route('admin.categories.review') }}" class="block px-4 py-2 hover:bg-gray-100">
                📊 Review Tag Combos
            </a>
        </li>
    </ul>
</aside>
