<?php

namespace App\Livewire;

use Livewire\Component;
use App\Services\CreatorCategoryService;
use Illuminate\Support\Auth;
use Illuminate\Support\Facades\Auth as FacadesAuth;

class ProfileUpdate extends Component
{
    public $region, $ethnicity, $body_type, $genre, $pronouns, $style_tags = [];

    public function mount()
    {
        $user = auth()->user();
        $this->region = $user->region;
        $this->ethnicity = $user->ethnicity;
        $this->body_type = $user->body_type;
        $this->genre = $user->genre;
        $this->pronouns = $user->pronouns;
        $this->style_tags = $user->style_tags ?? [];
    }

    public function save()
    {
        $user = auth()->user();
        $user->update([
            'region' => $this->region,
            'ethnicity' => $this->ethnicity,
            'body_type' => $this->body_type,
            'genre' => $this->genre,
            'pronouns' => $this->pronouns,
            'style_tags' => $this->style_tags,
        ]);

        $attributeSet = array_filter([
            $this->region,
            $this->ethnicity,
            $this->body_type,
            $this->genre,
            ...$this->style_tags,
        ]);

        CreatorCategoryService::syncCombinations($user, $attributeSet);

        session()->flash('message', 'Profile updated!');
    }

    public function render()
    {
        return view('livewire.profile-update');
    }
}
