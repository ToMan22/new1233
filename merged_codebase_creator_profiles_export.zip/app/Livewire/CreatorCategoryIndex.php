<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\CreatorCategoryCombination;

class CreatorCategoryIndex extends Component
{
    public $categories;

    public function mount()
    {
        $this->categories = CreatorCategoryCombination::where('is_published', true)->orderByDesc('count')->get();
    }

    public function render()
    {
        return view('livewire.creator-category-index')->title('All Creator Categories');
    }
}
