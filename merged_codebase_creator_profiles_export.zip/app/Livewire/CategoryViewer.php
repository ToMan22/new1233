<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\VideoCategoryCombination;
use App\Models\Video;

class CategoryViewer extends Component
{
    public $slug;
    public $combination;
    public $videos = [];

    public function mount($slug)
    {
        $this->slug = $slug;
        $this->combination = VideoCategoryCombination::where('slug', $slug)
            ->where('is_published', true)
            ->firstOrFail();

        $this->videos = Video::withAnyTags($this->combination->tag_ids)->get();
    }

    public function render()
    {
        return view('livewire.category-viewer')->title($this->combination->label);
    }
}
