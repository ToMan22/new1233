<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\VideoCategoryCombination;

class CategoryIndex extends Component
{
    public $categories;

    public function mount()
    {
        $this->categories = VideoCategoryCombination::where('is_published', true)->orderByDesc('count')->get();
    }

    public function render()
    {
        return view('livewire.category-index')->title('All Categories');
    }
}
