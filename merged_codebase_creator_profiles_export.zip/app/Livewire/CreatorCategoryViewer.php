<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\CreatorCategoryCombination;
use App\Models\User;

class CreatorCategoryViewer extends Component
{
    public $slug;
    public $combination;
    public $creators = [];

    public function mount($slug)
    {
        $this->slug = $slug;
        $this->combination = CreatorCategoryCombination::where('slug', $slug)
            ->where('is_published', true)
            ->firstOrFail();

        $query = User::query();
        foreach ($this->combination->attribute_ids as $attr) {
            $query->where(function($q) use ($attr) {
                $q->orWhere('region', $attr)
                  ->orWhere('ethnicity', $attr)
                  ->orWhere('body_type', $attr)
                  ->orWhere('genre', $attr)
                  ->orWhereJsonContains('style_tags', $attr);
            });
        }
        $this->creators = $query->get();
    }

    public function render()
    {
        return view('livewire.creator-category-viewer')->title($this->combination->label);
    }
}
