<?php

namespace App\Services;

use App\Models\CreatorCategoryCombination;
use Illuminate\Support\Str;

class CreatorCategoryService
{
    /**
     * Sync creator category combinations from selected attribute IDs.
     */
    public static function syncCombinations($user, array $attributeIds)
    {
        if (empty($attributeIds)) {
            return;
        }

        sort($attributeIds);
        $combinations = self::generateCombinations($attributeIds);

        foreach ($combinations as $combo) {
            $hash = self::generateHash($combo);
            $label = implode(' + ', $combo); // You may map to human-readable later
            $slug = Str::slug($label);

            $record = CreatorCategoryCombination::firstOrNew(['combination_hash' => $hash]);
            $record->slug = $slug;
            $record->label = $label;
            $record->attribute_ids = $combo;
            $record->combination_hash = $hash;
            $record->count = ($record->exists ? $record->count + 1 : 1);
            $record->suggested_by = $user->id ?? null;
            $record->save();
        }
    }

    /**
     * Generate all non-empty combinations of attribute IDs (up to 3-depth max).
     */
    public static function generateCombinations(array $items, $maxDepth = 3)
    {
        $results = [];

        $total = count($items);
        for ($i = 1; $i <= min($maxDepth, $total); $i++) {
            $results = array_merge($results, self::combinations($items, $i));
        }

        return $results;
    }

    public static function combinations(array $items, $k)
    {
        if ($k === 0) return [[]];
        if (count($items) < $k) return [];

        $head = array_slice($items, 0, 1);
        $rest = array_slice($items, 1);

        $combos = [];

        foreach (self::combinations($rest, $k - 1) as $combo) {
            $combos[] = array_merge($head, $combo);
        }

        return array_merge($combos, self::combinations($rest, $k));
    }

    public static function generateHash(array $ids): string
    {
        sort($ids);
        return md5(implode('-', $ids));
    }
}
