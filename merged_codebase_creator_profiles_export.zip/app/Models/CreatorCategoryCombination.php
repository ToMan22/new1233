<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreatorCategoryCombination extends Model
{
    protected $fillable = [
        'slug',
        'label',
        'attribute_ids',
        'combination_hash',
        'count',
        'is_featured',
        'is_approved',
        'is_published',
        'suggested_by',
        'published_at'
    ];

    protected $casts = [
        'attribute_ids' => 'array',
        'is_featured' => 'boolean',
        'is_approved' => 'boolean',
        'is_published' => 'boolean',
        'published_at' => 'datetime',
    ];
}
